#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Jul 19 10:29:20 2023

@author: niloofar
"""

# my_script.py
def add_numbers(a, b):
    return a + b

print(add_numbers(2, 3))