'''this is to test our model'''


import numpy as np
import GPy
import GPyOpt
from scipy.stats import norm
from pyDOE import lhs
from GPyOpt.methods import BayesianOptimization
from GPyOpt.acquisitions import AcquisitionEI
from scipy.stats import distributions
from GPyOpt.optimization import AcquisitionOptimizer

'''
   f= average q / rspT_diff
   avgQ= x[:,0]/5000
   and response time let's say we try some and know that
   
   [1,2,3] is for CPU, GPU and NNAPI delegate and this is static response time
   AI1 [50,30,10]
   AI2[60,20,50]
   AND we know AIs are both on NNAPI (OR X1 and X2=3) [X0,3,3] and their response time 
   is AI1=30 and AI2=55  [25,55]
   we assume two delegates:
   from current status [X0,3,3] to
   [X0,3,2]  makes reponse time of each [20,40]  
   [X0,2,2]  makes reponse time of each [40,30] 
   [X0,2,3]  makes reponse time of each [35,55] 
 AND cause Tris also matters, if 
   
   
   
'''
#staticAI1=[50,30,20]
#staticAI2=[60,20,40]
staticAI1=[30,10]
staticAI2=[20,50]

def timeDifference(rT): # calculates the average difference between all AIs current response time and exected responseT

    prefRtFac=1
    expectedAi1= min(staticAI1) *prefRtFac
    expectedAi2= min(staticAI2) *prefRtFac
    diffAry=[]
    averageDiff=[]
    for i in range(len(rT)):# this is for two AIs
      diff1=abs(rT[i][0]-expectedAi1)
      diff2=abs(rT[i][1]-expectedAi2)
      diffAry.append([diff1,diff2 ])
      averageDiff.append(( diff1+diff2) /2)               
    return averageDiff      

def calResponseT(x1,x2,x0factor): # this is the example of reponse time of two AIs while changing the delegate
 output=[] # here we also add the effect of triangle count
 for i in range(len(x1)):
  if x1[i]== 3 and x2[i]==2:
     output.append([20 +x0factor[i],40+x0factor[i]]) 
  elif x1[i]== 2 and x2[i]==2:
     output.append( [40+x0factor[i],30+x0factor[i]]) 
  elif x1[i]==2  and x2[i]==3:
     output.append(  [35+x0factor[i],55+x0factor[i]] )
  elif x1[i]==3  and x2[i]== 3:
     output.append( [25+x0factor[i],55+x0factor[i]])
 return output    

# Define the function to be optimized
def F(x):
    
    x = np.atleast_2d(x)
    q=x[:,0]/5000
 
    x0factor= x[:,0]*0.002 # this is the factor of tris on response time of AIs on each delegate 
    responseT=calResponseT( x[:,1],x[:,2], x0factor)
    avgdiff= timeDifference(responseT)
    # NOW  f= average q / rspT_diff
    output=q/avgdiff
    return output
    #return (x[:, 0] - 0.5) ** 2 + (x[:, 1] - 0.5) ** 2





# Define the bounds of the parameter space


# Define the kernel for the GP model
kernel = GPy.kern.Matern52(input_dim=3, variance=1.0, lengthscale=1.0)

# Define the initial set of points using Latin hypercube sampling
num_init_points = 4 # num of rows
# Define the bounds for each column

bounds = [(0, 5000), (2, 3), (2, 3)]
space = [{'name': 'x1', 'type': 'continuous', 'domain': (0, 5000)}, 
         {'name': 'x2', 'type': 'discrete', 'domain': (2, 3)},  
         {'name': 'x3', 'type': 'discrete', 'domain': (2, 3)}]

design_space = GPyOpt.Design_space(space=space)

# Define the number of samples
n_samples = 5


# Generate the Latin Hypercube Samples
#lhs_samples 
init_points= np.zeros((n_samples, len(bounds)), dtype=int)
for col, (min_val, max_val) in enumerate(bounds):
    init_points[:, col] = np.random.randint(min_val, max_val+1, size=n_samples)

print("Initial set of points:\n", init_points)

#init_points = lhs(3, samples=num_init_points, criterion='maximin')
func=F(init_points)

prior = GPyOpt.models.GPModel(kernel=kernel, optimize_restarts=5, verbose=False)

# Define the GP regression model
#prior = GPyOpt.models.GPRegression(X=init_points, Y=F(init_points).reshape(-1,1), kernel=kernel, noise_var=1e-10)
# Set the observed values in the GP regression model to the function values
#prior.set_XY(X=init_points, Y=F(init_points).reshape(-1,1))

       
acquisition_optimizer = AcquisitionOptimizer(design_space)
acquisition = AcquisitionEI(model=prior, space=design_space, optimizer=acquisition_optimizer, jitter=0.01)
# Define the acquisition function
#acquisition = AcquisitionEI(model=prior, space=design_space, jitter=0.01)
#print (acquisition.optimizer)
# Define the Bayesian optimization object
optimizer = GPyOpt.methods.ModularBayesianOptimization(
    model=prior,
    space=design_space,
    objective=F,
    acquisition=acquisition,
    evaluator=GPyOpt.core.evaluators.Sequential(acquisition),
    X_init=init_points,
    Y_init=F(init_points),
    #.reshape(-1, 1),
    normalize_Y=True,
)



next_point = optimizer.acquisition.optimize(optimizer.model)







while next_point is None:
    print('No suitable point found. Repeating optimization...')
    next_point = optimizer.acquisition.optimize(optimizer.model)

print('Next point to evaluate:', next_point)

for i in range(20):
    '''
    next_point = optimizer.acquisition.choose_next(points=optimizer.space.X, \
        model=optimizer.model, optimizer=None) # set optimizer to None
   '''
    next_point = optimizer.acquisition.optimize(optimizer.model)
   # next_point = lhs(2, samples=num_init_points, criterion='maximin')
   # Select the next point to evaluate using the acquisition function
  
    #next_point = np.array([1,2,3])
    #new_y = F(next_point)
    #prior.set_XY(X=next_point, Y=F(next_point).reshape(-1,1))
    prior = GPy.models.GPRegression(X=next_point, Y=F(next_point).reshape(-1,1), kernel=kernel, noise_var=1e-10)

    val = F(next_point).reshape(-1,1)
    #prior.space.add_new_point(next_point)
    prior = GPy.models.GPRegression(X=np.vstack((prior.X, next_point)), Y=np.vstack((prior.Y, val)), kernel=kernel, noise_var=1e-10)
    
    prior.update_model()
    
  
# Get the best point and the corresponding value
best_x = optimizer.X[np.argmin(optimizer.Y)]
best_y = np.min(optimizer.Y)

print("Best point:", best_x)
print("Best value:", best_y)


