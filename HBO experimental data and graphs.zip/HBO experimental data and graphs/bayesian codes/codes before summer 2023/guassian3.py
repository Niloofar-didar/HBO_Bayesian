import numpy as np
import GPy
import GPyOpt
from scipy.stats import norm
from pyDOE import lhs

# Define the function to be optimized
def F(x):
    x = np.atleast_2d(x)
    return (x[:, 0] - 0.5) ** 2 + (x[:, 1] - 0.5) ** 2

# Define the bounds of the parameter space
bounds = [{'name': 'x', 'type': 'continuous', 'domain': (0, 1)},
          {'name': 'y', 'type': 'continuous', 'domain': (0, 1)}]

# Define the kernel for the GP model
kernel = GPy.kern.Matern52(input_dim=2, variance=1.0, lengthscale=1.0)

# Define the initial set of points using Latin hypercube sampling
num_init_points = 5
init_points = lhs(2, samples=num_init_points, criterion='maximin')

# Define the GP regression model
prior = GPy.models.GPRegression(X=init_points, Y=np.zeros((num_init_points, 1)), kernel=kernel, noise_var=1e-10)
# Set the observed values in the GP regression model to the function values
prior.set_XY(X=init_points, Y=F(init_points).reshape(-1,1))


# Define the acquisition function
acquisition = GPyOpt.acquisitions.AcquisitionEI(model=prior, \
    space=GPyOpt.core.task.space.Design_space(bounds), \
    optimizer=None) # set optimizer to None

# Define the Bayesian optimization object

optimizer = GPyOpt.methods.ModularBayesianOptimization(
    model=prior,
    space=GPyOpt.core.task.space.Design_space(bounds),
    objective=F,
    acquisition=acquisition,
    evaluator=GPyOpt.core.evaluators.Sequential(acquisition),
     X_init=init_points,
     Y_init=F(init_points).reshape(-1,1),
    normalize_Y=True,
   # batch_size=2
)


for i in range(20):
    '''
    next_point = optimizer.acquisition.choose_next(points=optimizer.space.X, \
        model=optimizer.model, optimizer=None) # set optimizer to None
   '''
    next_point = lhs(2, samples=num_init_points, criterion='maximin')
   
    #next_point = np.array([1,2,3])
    #new_y = F(next_point)
    #prior.set_XY(X=next_point, Y=F(next_point).reshape(-1,1))
    prior = GPy.models.GPRegression(X=next_point, Y=F(next_point).reshape(-1,1), kernel=kernel, noise_var=1e-10)

    val = F(next_point).reshape(-1,1)
    #prior.space.add_new_point(next_point)
    prior = GPy.models.GPRegression(X=np.vstack((prior.X, next_point)), Y=np.vstack((prior.Y, val)), kernel=kernel, noise_var=1e-10)
    
    prior.update_model()
    
  
# Get the best point and the corresponding value
best_x = optimizer.X[np.argmin(optimizer.Y)]
best_y = np.min(optimizer.Y)

print("Best point:", best_x)
print("Best value:", best_y)


