# -*- coding: utf-8 -*-
"""
This is to generate graphs of weighted throughput and measured/estimated weights
Created on Tue Feb 14 13:12:32 2023
This is to check the graphs of estimated weight and measured weight
@author: gx7594
"""


from sklearn import datasets, linear_model
from sklearn.metrics import mean_squared_error, r2_score
from math import isnan
from statistics import mean
from sklearn.preprocessing import PolynomialFeatures
from sklearn.linear_model import LinearRegression
import pandas as pd
import numpy as np
import random
import matplotlib.pyplot as plt
import csv
import statistics
import math 
from sklearn.datasets import load_boston
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error, r2_score
from matplotlib import pyplot as plt
from matplotlib import pyplot as plt2
from matplotlib import pyplot as plt3
import os.path
from os import path
from matplotlib import rcParams
import datetime 
from datetime import datetime
from scipy.stats import linregress
import matplotlib as mpl


def estimate_coef(x, y):
    # number of observations/points
    n = np.size(x)
  
    # mean of x and y vector
    m_x = np.mean(x)
    m_y = np.mean(y)
  
    # calculating cross-deviation and deviation about x
    SS_xy = np.sum(y*x) - n*m_y*m_x
    SS_xx = np.sum(x*x) - n*m_x*m_x
  
    # calculating regression coefficients
    b_1 = SS_xy / SS_xx
    b_0 = m_y - b_1*m_x
  
    return (b_0, b_1)
  
def plot_regression_line(x, y, b):
    # plotting the actual points as scatter plot
    plt.scatter(x, y, color = "m",
               marker = "o", s = 30)
  
    # predicted response vector
    y_pred = b[0] + b[1]*x
  
    # plotting the regression line
    plt.plot(x, y_pred, color = "g")
  
    # putting labels
    plt.xlabel('x')
    plt.ylabel('y')
  
    # function to show plot
    plt.show()

#mpl.rcParams['axes.formatter.useoffset'] = False

from matplotlib.pyplot import figure

figure(figsize=(8, 6), dpi=80)


plt.rcParams['font.size'] = '17'
plt.rcParams['lines.markersize'] = 5
plt.rcParams["font.family"] = "Times New Roman"
plt.rcParams["axes.labelweight"] = "bold"
plt.rcParams["figure.autolayout"] = True

#read data "from" and store "to" location
#path ='exp4/' #this was for non-smoothed experiment, all aIs on NNAPI and we saw noisy variation in weights of window=3
#number= '11_22'# is related to specific file

#path ='good result/s22 exp/' #this is for smoothed weights using the function with alpha=0.7 and windows of 3
#number= '09_44'# is related to specific file
#the old good result path does't have balance function for RE

#path ='balance exp/exp1-s10/' #this is for smoothed weights using the function with alpha=0.7 and windows of 3
#number= '11_04'



#path ='balance exp/exp1_7/' #this is for smoothed weights using the function with alpha=0.7 and windows of 3
#number= '10_54'
#
#path ='balance exp/exp1_6/' #this is for smoothed weights using the function with alpha=0.7 and windows of 3
#number= '09_07'

#path ='balance exp/exp1_8/' #this is for smoothed weights using the function with alpha=0.7 and windows of 3
#number= '11_39'


#path ='good result/s22 exp/' #this is for smoothed weights using the function with alpha=0.7 and windows of 3
#number= '09_44'# is related to specific file
#path ='motivation/exp1_NNAPI/' #this is for smoothed weights using the function with alpha=0.7 and windows of 3
#number= '09_39'

path ='motivation/exp5/NNAPI/' #this is for smoothed weights using the function with alpha=0.7 and windows of 3
number= '12_06'
#path ='motivation/exp5/GPU/' #this is for smoothed weights using the function with alpha=0.7 and windows of 3
#number= '09_35'


path ='motivation/balancer test on flat parts after 8 objects/RE inclusive/' #this is for smoothed weights using the function with alpha=0.7 and windows of 3
number= '13_23'

path ='balance exp/exp1/' #this is for smoothed weights using the function with alpha=0.7 and windows of 3
number= '17_44'

path ='balance exp/exp3/' #this is for smoothed weights using the function with alpha=0.7 and windows of 3
number= '10_37'


path ='balance exp/test/' #this is for smoothed weights using the function with alpha=0.7 and windows of 3
number= '20_59'

#path ='motivation/exp2_GPU/' #this is for smoothed weights using the function with alpha=0.7 and windows of 3
#number= '10_26'


lines=[  'dashed','-.', '--',  ':', 'dashdot','solid', 'dotted', '',]
width=[2.5,4,2,3.5,3,3.5,4,4.5,5,5.5]


markers=['o','.','v','1','s','x','p','d']



''' graphs for weight test (measured and estimated)'''

infTime= pd.read_csv(path+'Weights'+number+'.csv')
ai_name=list(infTime['AI_name'].values.reshape(-1,1)[:,0]) 

MsrW=list(infTime['Msr_W'].values.reshape(-1,1)[:,0]) 
EstW=list(infTime['Est_W'].values.reshape(-1,1)[:,0]) 

ai_nameList=[]
for ai in ai_name:# to collect the list of current AI models
    if( (ai in ai_nameList)==False):
      if ai==  "inception_v1_224_quant ":
        ai="inception"
      ai_nameList.append(ai)
    else:# measn we've reached the replicated data
          break

# obtain per model measured and estimated weights
perAi_msrList=[]
perAi_estList=[]

perAi_pError=[] # percentage error per AI model for data collected

for k in range (0,len(ai_nameList)):
    perAi_msrList.append([])
    perAi_estList.append([])
    perAi_pError.append([])

i=0
while i< (len(MsrW)):
    l=0
    for k in range (0,len(ai_nameList)):# this is to add each AI model measured & estimated throughput
       tmpMList=perAi_msrList[k]
       tmpMList.append(MsrW[i+l])
       
       tmpEsList=perAi_estList[k]
       tmpEsList.append(EstW[i+l])
       
       tmpEr=perAi_pError[k]
       tmpEr.append( abs(EstW[i+l]-MsrW[i+l])*100/MsrW[i+l] )
       l+=1
       
    i=i+len(ai_nameList)
         
for k in range (0,len(ai_nameList)):# for all AI models we calculate average percentage error between estimated and measured Wi
  tmpEr=perAi_pError[k] # each AI percentage error data
  print("Average Percentage Error for Model "+ str(ai_nameList[k])+" is "
        + str(mean(tmpEr)))     
    
time=list(range(1,len(perAi_msrList[0])+1))  




infTime= pd.read_csv(path+'Weighted_throughput'+number+'.csv')

msrWthr=list(infTime['Weighted_msr_thr'].values.reshape(-1,1)[:,0]) 
aiS_accurate=list(infTime['All_AI_accuracy'].values.reshape(-1,1)[:,0]) 
estWthr=list(infTime['Weighted_pred_thr'].values.reshape(-1,1)[:,0]) 

avgMsrH=list(infTime['AVG_msr_thr'].values.reshape(-1,1)[:,0]) 
avgEstH=list(infTime['AVG_pred_thr'].values.reshape(-1,1)[:,0]) 
w_thErr=list(infTime['percentage_error'].values.reshape(-1,1)[:,0]) #error between avg measured and estimated thr


#remove data of zero tris since it's not accurate for modeling-no training for zero tris
k=0
while (w_thErr[k]>30):
        del msrWthr[k]
        del aiS_accurate[k]
        del estWthr[k]
        del avgMsrH[k]
        del avgEstH[k]
        del w_thErr[k]
        
time=list(range (0,len(estWthr)))
fig, ax = plt.subplots()
# foraverage measured and estimated  throughput graphs 
plt.plot(time ,avgMsrH , label='Avg_measured')
plt.plot(time ,avgEstH , label='Avg_estimated',linestyle='none',marker='o',markersize=8)

ax.set_xlabel('Time (s)')  
ax.set_ylabel('Throughput') 

ax.legend(loc="best",ncol=2,columnspacing=0.1,handletextpad=0.12,labelspacing = 0.1)#, fontsize=14) 
plt.tight_layout()
fig.savefig(  path+"AverageMsrEst.pdf" ,dpi=300)




aiS_acc=[]

for dat in aiS_accurate:
    if(dat==False):
        aiS_acc.append(0)
    else:
         aiS_acc.append(np.NAN)
  
maxerror=[10.0]*len(w_thErr)
fig, ax = plt.subplots()
# for percentage error
plt.plot(time ,maxerror , label='boundary',linestyle='solid',color='black')
plt.plot(time ,w_thErr , label='percentage error',linestyle='none',marker='x')
plt.plot(time ,aiS_acc , label='inaccurate AIs',linestyle='none',marker='o', markersize=6,color='red')



ax.set_xlabel('Time (s)')  
ax.set_ylabel('Percentage Error') 

ax.legend(loc="best",ncol=2,columnspacing=0.1,handletextpad=0.12,labelspacing = 0.1)#, fontsize=14) 
plt.tight_layout()

fig.savefig(  path+"pError.pdf" ,dpi=300)




fig, ax = plt.subplots()
# for measured and estimated weighted throughput graphs 
plt.plot(time ,msrWthr , label='W_measured_XMIR')
plt.plot(time ,avgMsrH , label='measured_MIR')
#plt.plot(time ,estWthr , label='W_estimated',linestyle='none',marker='o',markersize=8)

ax.set_xlabel('Time (s)')  
ax.set_ylabel('Throughput') 

ax.legend(loc="best",ncol=2,columnspacing=0.1,handletextpad=0.12,labelspacing = 0.1)#, fontsize=14) 
plt.tight_layout()

fig.savefig(  path+"XMIR_vs_MIR_msrthroughput.pdf" ,dpi=300)



fig, ax = plt.subplots()
# for measured and estimated weighted throughput graphs 
plt.plot(time ,estWthr , label='W_estimated_XMIR')
plt.plot(time ,avgEstH , label='estimated_MIR')
#plt.plot(time ,estWthr , label='W_estimated',linestyle='none',marker='o',markersize=8)
plt.ylim(0,max(avgEstH)+16)
ax.set_xlabel('Time (s)')  
ax.set_ylabel('Throughput') 

ax.legend(loc="best",ncol=2,columnspacing=0.1,handletextpad=0.12,labelspacing = 0.1)#, fontsize=14) 
plt.tight_layout()

fig.savefig(  path+"XMIR_vs_MIR_estthroughput.pdf",dpi=300)


### graph of per AI throughput model
thr= pd.read_csv(path+'Throughput'+number+'.csv')

msrInf1=list(thr['Inf1'].values.reshape(-1,1)[:,0]) 
msrOvh1=list(thr['Overhead1'].values.reshape(-1,1)[:,0]) 
msrInf2=list(thr['Inf2'].values.reshape(-1,1)[:,0]) 
msrOvh2=list(thr['Overhead2'].values.reshape(-1,1)[:,0]) 
msrInf3=list(thr['Inf3'].values.reshape(-1,1)[:,0]) 
msrOvh3=list(thr['Overhead3'].values.reshape(-1,1)[:,0]) 
msrthr=list(thr['Throughput_real'].values.reshape(-1,1)[:,0]) 
estthr=list(thr['Throughput_pred'].values.reshape(-1,1)[:,0]) 
tris=list(thr['Tris'].values.reshape(-1,1)[:,0]) 
trainedH=list(thr['trained_flag'].values.reshape(-1,1)[:,0]) 
rot=list(thr['rohT'].values.reshape(-1,1)[:,0]) 
rod=list(thr['rohD'].values.reshape(-1,1)[:,0]) 



time=list(range (0,len(estWthr)))
perAi_msrRtL=[]
perAi_msrthrL=[]
perAi_estthrL=[]
perAi_tris=[]
perAI_trained=[]
perAirohT=[]
perAirohD=[]
 # percentage error per AI model for data collected

for k in range (0,len(ai_nameList)):
    perAi_msrRtL.append([])
    perAi_msrthrL.append([])
    perAi_estthrL.append([])
    perAi_tris.append([])
    perAI_trained.append([])
    perAirohT.append([])
    perAirohD.append([])
    
i=0
while i< (len(msrthr)):
    l=0
    for k in range (0,len(ai_nameList)):# this is to add each AI model measured & estimated throughput
       tmpMrList=perAi_msrRtL[k]
       if(k==0):
         tmpMrList.append(msrInf1[i+l]+msrOvh1[i+l])
       elif(k==1):
           tmpMrList.append(msrInf2[i+l]+msrOvh2[i+l])
       elif(k==2):
           tmpMrList.append( msrInf3[i+l]+msrOvh3[i+l])
         
       tmprot=    perAirohT[k]
       tmprot.append(rot[i+l])
       
       tmproD=    perAirohD[k]
       tmproD.append(rod[i+l])
       
       tmpMList=perAi_msrthrL[k]
       tmpMList.append(msrthr[i+l])
       
       tmpEsList=perAi_estthrL[k]
       tmpEsList.append(estthr[i+l])
       
       tmptrainList=perAI_trained[k]
       x=np.nan
       if(trainedH[i+l]==True):#this is to be able to show where are trained H in a graph, nan are non shown
           x=1
           
       tmptrainList.append(x)
       
       tmpEt=perAi_tris[k]
       tmpEt.append(tris[i+l])
       
       l+=1
       
    i=i+len(ai_nameList)
    
    
    
    
#fig, ax = plt.subplots()   
time=list(range(0,len(perAi_msrthrL[0])))

# for measured weight

for k in range (0,len(ai_nameList)):    
  msrdAI=perAi_msrthrL[k]  
  trisAI=perAi_tris[k]
  #plt.plot(trisAI ,msrdAI , label=ai_nameList[k],linewidth=0.99+(2*k/3))




tris_changeInd=[]
newT=trisAI[0]
final_index=0
#tris_changeInd.append(final_index)
## This is to find triangle change points of time
while(final_index+1<len(trisAI)):
    element = newT
    # finding the last occurrence
    final_index = max(index for index, item in enumerate(trisAI) if item == element)
    if(final_index+1<len(trisAI)):  
       tris_changeInd.append(final_index+1)
  
       newT=trisAI[final_index+1]

'''here we calculate average throughput per tris change per AI'''
avg_thr_perAI=[]


fig, ax = plt.subplots()
# for measured and estimated weighted throughput graphs 

trischange_perAI=[]

for k in range(0,len(perAi_tris)):# up to the count of ai models
   msr_thr=perAi_msrthrL[k] # measured throughput per AI model
   start=0
   avg_thr=[]

   for index in tris_changeInd :
     msdH= msr_thr[start:index]
     avg= mean(msdH )
     avg_thr.append(avg)
     if(k==0):# just one time record the tris variation
       trischange_perAI.append(perAi_tris[0][index-1])
     start=index
   
   avg_thr_perAI.append(avg_thr)
   plt.plot(trischange_perAI ,avg_thr , label=ai_nameList[k])
   
   end=7
   x = np.array(trischange_perAI[0:end])
   y = np.array(avg_thr[0:end])
    # estimating coefficients
   b = estimate_coef(x, y)
   print("ThroughputModel: "+str(ai_nameList[k])+"Estimated coefficients:\nb_0 = {} \
          \nb_1 = {}".format(b[0], b[1]))





ax.set_xlabel('Triangle Count')  
ax.set_ylabel('Average Throughput(fps)') 
#plt.ylim(0,65)
ax.legend(loc="best",ncol=2,columnspacing=0.1,handletextpad=0.12,labelspacing = 0.1)#, fontsize=14) 
plt.tight_layout()
fig.savefig(  path+"msr_perAI_thr_tris.pdf" ,dpi=300)    




fig, ax = plt.subplots()   
time=list(range(0,len(perAi_msrthrL[0])))

for k in range (0,len(ai_nameList)):    
  msrdAI=perAi_msrthrL[k]  
  plt.plot(time ,msrdAI , label=ai_nameList[k],linewidth=0.99+(2*k/3))


first = True
for point in tris_changeInd:
     if(first==True):
       plt.plot(point ,1 , label="Tris Change",marker='x', color='red')
       first=False
     else:
        plt.plot(point ,1 ,marker='x', color='red')
  

#plt.xlim(200,400)
ax.set_xlabel('Time')  
ax.set_ylabel('Throughput(fps)') 
ax.legend(loc="best",ncol=2,columnspacing=0.1,handletextpad=0.12,labelspacing = 0.1)#, fontsize=14) 
plt.tight_layout()
fig.savefig(  path+"msr_perAI_thr_time.pdf" ,dpi=300)  
####### measured per AI throughput



# rohT and rohD during Time
fig, ax = plt.subplots()   
fig2, ax2 = plt.subplots()   
time=list(range(0,len(perAi_msrthrL[0])))
#for k in range (0,len(ai_nameList)):    
for k in range (0,1):
  rohT=perAirohT[k]  
  rohD=perAirohD[k]  
  #plt.plot(time ,rohT , label=ai_nameList[k]+"rohT",linewidth=0.99+(2*k/3))
  plt2.plot(time ,rohD , label=ai_nameList[k]+"rohD",linewidth=0.99+(2*k/3))


first = True
for point in tris_changeInd:
     if(first==True):
       #plt.plot(point ,1 , label="Tris Change",marker='x', color='red')
       plt2.plot(point ,1 , label="Tris Change",marker='x', color='red')
   
       first=False
     else:
        #plt.plot(point ,1 ,marker='x', color='red')
        plt2.plot(point ,1 ,marker='x', color='red')
'''
#plt.ylim(-300,200)    
ax.set_xlim(200,400)  
#ax.set_yscale('log')
ax.set_xlabel('Time')  
ax.set_ylabel('rohT') 
ax.legend(loc="best",ncol=2,columnspacing=0.1,handletextpad=0.12,labelspacing = 0.1)#, fontsize=14) 
plt.tight_layout()
fig.savefig(  path+"rohT.pdf" ,dpi=300)  
'''


#ax.set_yscale('log')
ax2.set_xlabel('Time')  
ax2.set_ylabel('rohD') 
ax2.legend(loc="best",ncol=2,columnspacing=0.1,handletextpad=0.12,labelspacing = 0.1)#, fontsize=14) 
plt2.tight_layout()
fig2.savefig(  path+"rohD.pdf" ,dpi=300)  



# rohT and rohD during Time

####### measured per AI Response Time
fig, ax = plt.subplots()   
time=list(range(0,len(perAi_msrRtL[0])))

for k in range (0,len(ai_nameList)):    
  msrdAI=perAi_msrRtL[k]  
  plt.plot(time ,msrdAI , label=ai_nameList[k],linewidth=0.99+(2*k/3))


first = True
for point in tris_changeInd:
     if(first==True):
       plt.plot(point ,1 , label="Tris Change",marker='x', color='red')
       first=False
     else:
        plt.plot(point ,1 ,marker='x', color='red')
  

ax.set_xlabel('Time')  
ax.set_ylabel('Response Time(ms)') 
ax.legend(loc="best",ncol=2,columnspacing=0.1,handletextpad=0.12,labelspacing = 0.1)#, fontsize=14) 
plt.tight_layout()
fig.savefig(  path+"msr_perAI_Responsetime.pdf" ,dpi=300)  



'''here we calculate average Response Time per tris change per AI'''
avg_rt_perAI=[]
fig, ax = plt.subplots()

trischange_perAI=[]

for k in range(0,len(perAi_tris)):# up to the count of ai models
   msr_rt=perAi_msrRtL[k] # measured throughput per AI model
   start=0
   avg_rt=[]

   for index in tris_changeInd :
     msdT= msr_rt[start:index]
     avg= mean(msdT )
     avg_rt.append(avg)
     if(k==0):# just one time record the tris variation
       trischange_perAI.append(perAi_tris[0][index-1])
     start=index
   
   avg_rt_perAI.append(avg_rt)
   plt.plot(trischange_perAI ,avg_rt , label=ai_nameList[k])
   end=7
   x = np.array(trischange_perAI[0:end])
   y = np.array(avg_rt[0:end])
   # estimating coefficients
   b = estimate_coef(x, y)
   print("ResponseT: "+str(ai_nameList[k])+"Estimated coefficients:\nb_0 = {} \
        \nb_1 = {}".format(b[0], b[1]))


ax.set_xlabel('Triangle Count')  
ax.set_ylabel('Average ResponseTime(fps)') 
plt.ylim(0,120)
ax.legend(loc="best",ncol=2,columnspacing=0.1,handletextpad=0.12,labelspacing = 0.1)#, fontsize=14) 
plt.tight_layout()
fig.savefig(  path+"msr_perAI_ResponseTime_tris.pdf" ,dpi=300)  


####### measured per AI Responsetime





time=list(range(1,len(perAi_msrList[0])+1))  
fig, ax = plt.subplots()
# for estimated weight
for k in range (0,len(ai_nameList)):    
  estAI=perAi_estList[k]  
  plt.plot(time,estAI, label=ai_nameList[k], marker=markers[k], )


first = True
for point in tris_changeInd:
     if(first==True ):
       plt.plot(point ,0.1 , label="Tris Change",marker='x', color='red')
       first=False
     else:
        plt.plot(point ,0.1 ,marker='x', color='red')

plt.ylim(0,1.43)
#plt.xlim(200,250)
ax.set_xlabel('Time (s)')  
ax.set_ylabel('Normalized weight (0-1)') 

ax.legend(loc="best",ncol=2,columnspacing=0.1,handletextpad=0.12,labelspacing = 0.1)#, fontsize=14) 
plt.tight_layout()
fig.savefig(path+"estimated_weights.pdf" ,dpi=300)
# for estimated weight



#Monitor GPU usage during time

gpu_file= pd.read_csv( path+"GPU_Usage_"+number+".csv")
gpu=list(gpu_file["gpu"].values.reshape(-1,1)[:,0])#reshap(-1,1) means to convert the array of unknown dimensio into one-d array
tris=list(gpu_file['tris'].values.reshape(-1,1)[:,0])
time=list(range(1,len(gpu)+1))

fig, ax = plt.subplots()

plt.plot(time ,gpu )
ax.set_xlabel('Time (s)')  
ax.set_ylabel('GPU Usage (0-100)') 

ax.legend(loc="best",ncol=2,columnspacing=0.1,handletextpad=0.12,labelspacing = 0.1)#, fontsize=14) 
plt.tight_layout()

fig.savefig(  path+"GPU_usage.pdf",dpi=300)

'''
fig, ax = plt.subplots()
plt.plot(tris ,gpu )
ax.set_xlabel('Triangle Count')  
ax.set_ylabel('GPU Usage (0-100)') 

ax.legend(loc="best",ncol=2,columnspacing=0.1,handletextpad=0.12,labelspacing = 0.1)#, fontsize=14) 
plt.tight_layout()

fig.savefig(  path+"GPU_usage_tris.pdf",dpi=300)
'''

# monitor RE during time

re_file= pd.read_csv( path+"RE"+number+".csv")
re_Real=list(re_file["re_Real"].values.reshape(-1,1)[:,0])#reshap(-1,1) means to convert the array of unknown dimensio into one-d array
re_pred=list(re_file["re_pred"].values.reshape(-1,1)[:,0])#reshap(-1,1) means to convert the array of unknown dimensio into one-d array
trainedRe=list(re_file["trainedRe"].values.reshape(-1,1)[:,0])#reshap(-1,1) means to convert the array of unknown dimensio into one-d array
recalT=list(re_file["Recalculated Tris"].values.reshape(-1,1)[:,0])#reshap(-1,1) means to convert the array of unknown dimensio into one-d array

#re_file= pd.read_csv( path+"Weights"+number+".csv")
#estW=list(re_file["Est_W"].values.reshape(-1,1)[:,0])#reshap(-1,1) means to convert the array of unknown dimensio into one-d array



index=trainedRe.index(True)# the first index where RE is trained
re_Real=re_Real[index:len(re_Real)]
re_pred=re_pred[index:len(re_pred)]
recalT=recalT[index:len(recalT)]
time=list(range(1,len(re_Real)+1))

boundMax=[1.2]*len(re_Real)
boundMin=[0.8]*len(re_Real)

fig, ax = plt.subplots()

plt.plot(time,re_Real,label='measured', marker=markers[1],linestyle='none')
plt.plot(time,re_pred,label='estimated')
plt.plot(time,boundMax,label='boundary',color='black')
plt.plot(time,boundMin,color='black')
ax.set_xlabel('Time (s)')  
ax.set_ylabel('RE') 

firsttime=False
for i in range (0,len(recalT)):
    if(recalT[i]==True):
        if firsttime==False:
           plt.plot(time[i],0.7, marker='x',color='red',label='balancer', markersize=10.15,markeredgewidth=2.5)
           firsttime=True
        else:
         plt.plot(time[i],0.7, marker='x', markersize=10.15,markeredgewidth=1.5,color='red')
      
#plt.xlim(330,400)
ax.legend(loc="best",ncol=2,columnspacing=0.1,handletextpad=0.12,labelspacing = 0.1)#, fontsize=14) 
plt.tight_layout()
fig.savefig(path+"RE.pdf" ,dpi=300) 
