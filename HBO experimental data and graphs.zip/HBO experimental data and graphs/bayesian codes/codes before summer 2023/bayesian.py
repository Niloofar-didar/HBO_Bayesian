import numpy as np
import GPy
import GPyOpt
from scipy.stats import norm
from numpy.linalg import cholesky, det, lstsq
from pyDOE import lhs

# define the objective function
def F(x):
    # evaluate the function here, replace with your function
    y = (6*x-2)**2*np.sin(12*x-4)
    return y

# define the bounds of the search space
bounds = [{'name': 'x', 'type': 'continuous', 'domain': (0, 1)}]

# define the kernel for the GP model
kernel = GPy.kern.Matern52(input_dim=1, variance=1.0, lengthscale=0.2)

# initialize the design of experiments
init_points = lhs(1, samples=5, criterion='maximin')
init_points = np.array([bounds[i]['domain'][0] + (bounds[i]['domain'][1] - bounds[i]['domain'][0]) * init_points[:, i] for i in range(init_points.shape[1])]).T

# initialize the GP model
prior = GPy.models.GPRegression(X=np.array(init_points), Y=F(init_points), kernel=kernel, noise_var=1e-10)

# define the acquisition function
def expected_improvement(x, model, best_y, xi=0.01):
    """
    Expected improvement acquisition function.
    """
    X = model.X
    m, s = model.predict(x.reshape(-1, 1))
    s = np.sqrt(s)
    z = (m - best_y - xi) / s
    val = (m - best_y - xi) * norm.cdf(z) + s * norm.pdf(z)
    return val[0]

# initialize the optimization algorithm
acquisition = GPyOpt.acquisitions.AcquisitionEI(model=prior, jitter=0.01,
  space=GPyOpt.core.task.space.Design_space(bounds))

optimizer = GPyOpt.methods.ModularBayesianOptimization(
    model=prior,
    space=GPyOpt.core.task.space.Design_space(bounds),
    objective=F,
    acquisition=acquisition,
    evaluator=GPyOpt.core.evaluators.Sequential(acquisition),
     X_init=init_points,
     Y_init=F(init_points).reshape(-1,1),
    normalize_Y=True,
   # batch_size=2
)
# run the optimization loop
max_iter = 20
for i in range(max_iter):
    next_point = optimizer.suggest_next_locations()
    f_val = F(next_point)
    optimizer.update_design(next_point, f_val)
    optimizer._update_model()
    best_x, best_y = optimizer.get_best()
    print(f'Iteration {i+1}, Best value: {best_y}, Best point: {best_x}')
