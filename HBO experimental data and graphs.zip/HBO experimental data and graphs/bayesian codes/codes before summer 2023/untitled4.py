# -*- coding: utf-8 -*-
"""
Created on Wed May 10 11:33:41 2023

@author: gx7594
"""

import numpy as np
import GPyOpt
from GPyOpt.methods import BayesianOptimization

def F(x):
    x = np.atleast_2d(x)
    q=x[:,0]/5000
 
    x0factor= x[:,0]*0.002 # this is the factor of tris on response time of AIs on each delegate 
    responseT=calResponseT( x[:,1],x[:,2], x0factor)
    avgdiff= timeDifference(responseT)
    # NOW  f= average q / rspT_diff
    output=q/avgdiff
    return output

# Define the bounds of the parameter space
bounds = [{'name': 'x0', 'type': 'continuous', 'domain': (0, 5000)},
          {'name': 'x1', 'type': 'discrete', 'domain': (2, 3)},
          {'name': 'x2', 'type': 'discrete', 'domain': (2, 3)}]

# Define the kernel for the GP model
kernel = GPyOpt.kernels.Matern52(input_dim=3, ARD=True)

# Define the initial set of points using Latin hypercube sampling
num_init_points = 4
init_points = np.random.rand(num_init_points, 3)
for i, b in enumerate(bounds):
    if b['type'] == 'continuous':
        init_points[:, i] = init_points[:, i] * (b['domain'][1] - b['domain'][0]) + b['domain'][0]
    elif b['type'] == 'discrete':
        init_points[:, i] = np.round(init_points[:, i] * (b['domain'][1] - b['domain'][0]) + b['domain'][0])

# Define the Gaussian process model
prior = GPyOpt.models.GPModel(kernel=kernel, optimize_restarts=5, verbose=False)

# Define the acquisition function
acquisition = GPyOpt.acquisitions.AcquisitionEI(prior)

# Define the Bayesian optimizer
optimizer = BayesianOptimization(f=F, domain=bounds, model_type='GP', initial_design_numdata=num_init_points,
                                  initial_design_type='random', acquisition=acquisition, maximize=True)

# Run the optimization
max_iter = 10
for i in range(max_iter):
    next_point = optimizer.suggest_next_locations()
    optimizer.register_new_data(init_points, F(init_points))
    print("Iteration {}: maximum value found = {}".format(i+1, optimizer.fx_opt))
