import numpy as np


# Define the reward function
def reward_function(x):
    # Calculate the reward based on the input combination x
    # Replace this with your actual reward calculation
    x1, x2, x3, x4 = x[:, 0], x[:, 1], x[:, 2], x[:, 3]
    reward =  x[:, 4] # Example reward calculation
    return reward.reshape(-1, 1)

# Define the bounds of the input variables
bounds = np.array([(0, 1), (0, 1), (0, 1), (1, 10000)])

# Generate all possible combinations of x1, x2, and x3
#combinations = np.array([[i, j, 1 - i - j] for i in [0, 1/3, 2/3, 1] for j in [0, 1/3, 2/3, 1] if i + j <= 1])

# Convert the input data to numpy array
#input_data = np.hstack((combinations, np.zeros((combinations.shape[0], 1))))

# Extract the input combinations and rewards



input_data = np.array([[1.0, 0.0, 0.0, 434.9334, -29.48666666666667],
                       [0.6666666666666666, 0.3333333333333333, 0.0, 434.9334, -31.333333333333336],
                       [0.6666666666666666, 0.0, 0.3333333333333333, 434.9334, -3.740000000000001],
                       [0.3333333333333333, 0.6666666666666666, 0.0, 434.9334, -43.71666666666667],
                       [0.3333333333333333, 0.3333333333333333, 0.3333333333333333, 434.9334, 6.1000000000000005],
                       [0.3333333333333333, 0.0, 0.6666666666666666, 434.9334, 21.493333333333336],
                       [0.0, 1.0, 0.0, 434.9334, -32.07666666666667],
                       [0.0, 0.6666666666666666, 0.3333333333333333, 434.9334, 4.706666666666665],
                       [0.0, 0.3333333333333333, 0.6666666666666666, 434.9334, 17.233333333333334],
                       [0.0, 0.0, 1.0, 434.9334, -44.440000000000005]])

rewards = input_data[:, 4:]
input_combinations =[]
#combinations=input_combinations
# Normalize the rewards
rewards_normalized = (rewards - np.mean(rewards)) / np.std(rewards)

# Define the number of iterations
num_iterations = 10

# Initialize the best input and reward
best_input = None
best_reward = float('-inf')
input_combinations=[[1.0, 0.0, 0.0, 434.9334, -29.48666666666667], [0.6666666666666666, 0.3333333333333333, 0.0, 434.9334, -31.333333333333336]]
corr_rewards_normalized=rewards_normalized[0:2]


# Perform Bayesian optimization
for _ in range(num_iterations):
    # Generate random indices within the range of combinations
    indices = np.random.randint(len(input_data), size=5)
    # Retrieve the input combinations based on the random indices
    next_input_combinations = input_data[indices]
    
    # Calculate the fourth input x4 based on the constraint x1 + x2 + x3 = 1
    next_input_sum = np.sum(next_input_combinations, axis=1, keepdims=True)
   
    #np.concatenate((next_input_combinations, input_data[:, :4]), axis=1)
    
    # Evaluate the reward function for the next input samples
    next_reward = reward_function(next_input_combinations)
    next_reward_normalized = (next_reward - np.mean(rewards)) / np.std(rewards)
    
    # Find the best input sample
    max_index = np.argmax(next_reward_normalized)
    
    # Check if the new sample improves the best reward
    if next_reward_normalized[max_index] > best_reward:
        best_input = next_input_combinations[max_index]
        best_reward = next_reward_normalized[max_index]
    
    # Add the new samples to the dataset
    input_combinations = np.concatenate((input_combinations, next_input_combinations))
    rewards_normalized = np.concatenate((corr_rewards_normalized, next_reward_normalized))

# Denormalize the best input
best_input_denormalized = bounds[:, 0] + best_input * (bounds[:, 1] - bounds[:, 0])

print("Best input combination:", best_input_denormalized)
print("Best reward:", best_reward)
