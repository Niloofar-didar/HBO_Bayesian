#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Jul 17 10:24:10 2023

@author: niloofar
"""
'''

this is the code we went through with Dr brocanlli



'''


import pandas as pd
from sklearn import datasets, linear_model
from sklearn.metrics import mean_squared_error, r2_score
from math import isnan
from statistics import mean
from sklearn.preprocessing import PolynomialFeatures
from sklearn.linear_model import LinearRegression
import pandas as pd
import numpy as np
import random
import matplotlib.pyplot as plt
import csv
import statistics
import math 
from sklearn.datasets import load_boston
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error, r2_score
from matplotlib import pyplot as plt
from matplotlib import pyplot as plt2
from matplotlib import pyplot as plt3
import os.path
from os import path
from matplotlib import rcParams
import datetime 
from datetime import datetime
from scipy.stats import linregress
import matplotlib as mpl
import GPyOpt
import GPy
import numpy as npv
import numpy as np
import pandas as pd
from sklearn import datasets, linear_model
from sklearn.metrics import mean_squared_error, r2_score
from math import isnan
from statistics import mean
from sklearn.preprocessing import PolynomialFeatures
from sklearn.linear_model import LinearRegression
import pandas as pd
import numpy as np
import random
import matplotlib.pyplot as plt
import csv
import statistics
import math 
from sklearn.datasets import load_boston
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error, r2_score
from matplotlib import pyplot as plt
from matplotlib import pyplot as plt2
from matplotlib import pyplot as plt3
import os.path
from os import path
from matplotlib import rcParams
import datetime 
from datetime import datetime
from scipy.stats import linregress
import matplotlib as mpl





from matplotlib.pyplot import figure

import GPyOpt
from GPyOpt.methods import BayesianOptimization

#numpy
import numpy as np
from numpy.random import multivariate_normal #For later example

import pandas as pd

#Plotting tools
from mpl_toolkits.mplot3d import Axes3D
import matplotlib.pyplot as plt
from matplotlib import cm
from matplotlib.ticker import LinearLocator, FormatStrFormatter
import numpy as np
from numpy.random import multivariate_normal




##############333 This is another example to plot acquisition function

'''
def objfunc2d(x):
    """
    x is a 2 dimensional vector.
    """ 
    x1 = x[:, 0]
    x2 = x[:, 1]
    return((x1**2 + x2**2)*(np.sin(x1)**2 - np.cos(x2)))

bounds2d = [{'name': 'var_1', 'type': 'discrete', 'domain': (0,1, 2,4,6,8,10)},
            {'name': 'var_2', 'type': 'discrete', 'domain': (0,1,2,4,6,8,10)}]
maxiter = 50

myBopt_2d = GPyOpt.methods.BayesianOptimization(objfunc2d, domain=bounds2d,constraints=[{'name': 'constr_1', 'constraint': '(x[:, 0] + x[:, 1] - 10) '}])

myBopt_2d.run_optimization(max_iter = maxiter)
print("="*20)
print("Value of (x,y) that minimises the objective:"+str(myBopt_2d.x_opt))    
print("Minimum value of the objective: "+str(myBopt_2d.fx_opt))     
print("="*20)
myBopt_2d.plot_acquisition()

'''

##############333 This is another example



def remove_duplicates(lst):
    seen = set()
    result = []

    for sublst in lst:
        subtuple = tuple(sublst)
        if subtuple not in seen:
            seen.add(subtuple)
            result.append(sublst)

    return result


lines=[  'dashed','-.',':', '--',   'solid', 'dotted', '',]
width=[2.5,4,2,3.5,3,3.5,4,4.5,5,5.5]

markers=['o','.','v','1','s','x','p','d']


path ='Bayesian_dataCollection19:19.csv' #this is for smoothed weights using the function with alpha=0.7 and windows of 3

data= pd.read_csv(path)

rt1=list(data['RT1'].values.reshape(-1,1)[:,0]) 
 
rt2=list(data['RT2'].values.reshape(-1,1)[:,0]) 

rt3=list(data['RT3'].values.reshape(-1,1)[:,0]) 

tris=list(data['Tris'].values.reshape(-1,1)[:,0]) 

avgQ=list(data['avgQ'].values.reshape(-1,1)[:,0]) 

dev1=list(data['Device1'].values.reshape(-1,1)[:,0]) 
dev2=list(data['Device2'].values.reshape(-1,1)[:,0]) 
dev3=list(data['Device3'].values.reshape(-1,1)[:,0]) 


model1=list(data['Model1'].values.reshape(-1,1)[:,0]) 
model2=list(data['Model2'].values.reshape(-1,1)[:,0]) 
model3=list(data['Model3'].values.reshape(-1,1)[:,0]) 


input_data=[]

utl_devices=[] # CPU utilization

for i in range (0,len(rt1)):
    utl_devices.append(  [ round((dev1[i].count("CPU")+ dev2[i].count("CPU") +dev3[i].count("CPU")) /3,1)  
   ,  round((dev1[i].count("GPU")+ dev2[i].count("GPU") +dev3[i].count("GPU")) /3,1 ) 
   ,   round((dev1[i].count("NNAPI")+ dev2[i].count("NNAPI") +dev3[i].count("NNAPI")) /3,1) ] )
    
    
expected_RT=50# let's assume this is for all AI inferences    
avglatency=[]    

for i in range (0,len(rt1)):
  avglatency.append( ((rt1[i]-50)+ (rt2[i]-50) +(rt3[i]-50))/3)

for i in range (0,len(rt1)):
  input_data.append([float(round(utl_devices[i][0],1)),float(round(utl_devices[i][1],1)),float(round(utl_devices[i][2],1)),float(round(tris[i])),float(round(avgQ[i],2)-avglatency[i]) ])  






import itertools
from operator import itemgetter
from operator import itemgetter

three_column_vals = list(map(itemgetter(0,1,2,3), input_data))         # [1, 3, 5]


uniqueInput=remove_duplicates(three_column_vals)

def get_result_element(list_of_lists, first_three_elements):# this is to get the quality correponded to the input values
    for sublist in list_of_lists:
        if sublist[:4] == first_three_elements:
            return sublist[4]
    return None 



result = get_result_element(input_data, 
[1.0, 0.0, 0.0,435])



import numpy as np
import GPyOpt
import random
from itertools import product
from bayes_opt import BayesianOptimization
from bayes_opt.util import UtilityFunction
# Define the reward function





def reward_function(x):
    # Calculate the reward based on the input combination x
    # Replace this with your actual reward calculation
    x1, x2, x3,x4 = x[:, 0], x[:, 1], x[:, 2], x[:, 3],
    #reward= (x1+x2 )*x3
    reward= get_result_element(input_data,  [x1,x2,x3,x4])
    return (reward*-1)
    #reward = -((x1 - 0.5)**2 + (x2 - 0.5)**2 + (x3 - 500)**2)  # Example reward calculation
    #return reward.reshape(-1, 1)

# Define the bounds of the input variables
bounds = [{'name': 'x1', 'type': 'discrete', 'domain': (0, 0.3, 0.7, 1)},
          {'name': 'x2', 'type': 'discrete', 'domain': (0, 0.3, 0.7, 1)},
          {'name': 'x3', 'type': 'discrete', 'domain': (0, 0.3, 0.7, 1)},
         {'name': 'x4', 'type': 'discrete', 'domain': (435, 217, 43)},]
          #{'name': 'x4', 'type': 'continuous', 'domain': (100, 1000)}]

'''
###########test
'''

max_iter = 5 # Number of optimization iterations
(max_iter)
max_time  = None 
tolerance = 1e-8 
# --- CHOOSE the type of acquisition

space = [{'name': 'var_1', 'type': 'discrete', 'domain': (0, 0.3, 0.7, 1)},
          {'name': 'var_2', 'type': 'discrete', 'domain': (0, 0.3, 0.7, 1)},
         {'name': 'var_3', 'type': 'discrete', 'domain': (0, 0.3, 0.7, 1)},
        {'name': 'var_4', 'type': 'discrete', 'domain':  (435, 217, 43)}
          ]

feasible_region = GPyOpt.Design_space(space = space, constraints= [{'name': 'constr_1', 'constraint': 'np.abs(x[:, 0] + x[:, 1] + x[:, 2]- 1) '}])

# --- CHOOSE the model type
#model = GPyOpt.models.GPModel(exact_feval=True,optimize_restarts=10,verbose=False)

# --- CHOOSE the acquisition optimizer
#aquisition_optimizer = GPyOpt.optimization.AcquisitionOptimizer(feasible_region)

# --- CHOOSE the type of acquisition
#acquisition = GPyOpt.acquisitions.AcquisitionEI(model, feasible_region, optimizer=aquisition_optimizer)

'''
#########test
'''

# Create the optimization problem
#problem = GPyOpt.methods.BayesianOptimization(f=reward_function, domain=bounds)
problem = GPyOpt.methods.BayesianOptimization(reward_function, domain=space , constraints= [{'name': 'constr_1', 'constraint': 'np.abs(x[:, 0] + x[:, 1] +x[:, 2] - 1) '}])
# distance between two consecutive observations  
# Run the optimization                                                  
problem.run_optimization(max_iter = max_iter)
                         #, max_time = max_time, eps = tolerance, verbosity=False) 
problem.plot_acquisition()
problem.plot_convergence()
best_input = problem.x_opt
best_reward = problem.fx_opt

#upper confidence bounds by default has a good  convergence rate


print("Best input combination: for iteration #" +str(max_iter), best_input)
print("Best reward:", best_reward)



max_iter  = 20
problem.run_optimization(max_iter = max_iter, max_time = max_time, eps = tolerance, verbosity=False) 


# Get the best input combination and reward
best_input = problem.x_opt
best_reward = problem.fx_opt

print("Value of input that minimises the objective: for iteration #" +str(max_iter), best_input)
print("Minimum value of the objective:", best_reward)

#fig, ax = plt.subplots()
problem.plot_acquisition()
problem.plot_convergence()




