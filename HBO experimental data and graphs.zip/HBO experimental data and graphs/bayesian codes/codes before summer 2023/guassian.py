import GPyOpt
import numpy as np
import GPy

import sys
print(sys.version)

# Define the function to be optimized
def F(x):
    return (x[:, 0]**2 + x[:, 1]**2 + x[:, 2]**2) * np.sin(x[:, 0])

# Define the bounds for each column
bounds = [(0, 5000), (2, 3), (2, 3)]

# Define the design space
space = [{'name': 'x1', 'type': 'continuous', 'domain': (0, 5000)}, 
         {'name': 'x2', 'type': 'discrete', 'domain': (2, 3)},  
         {'name': 'x3', 'type': 'discrete', 'domain': (2, 3)}]
design_space = GPyOpt.Design_space(space=space)

# Define the initial set of points using Latin hypercube sampling
num_init_points = 5
init_points = GPyOpt.initial_design.random_init(design_space, num_init_points)
# Define the kernel for the GP model
kernel = GPy.kern.Matern52(input_dim=3, variance=1.0, lengthscale=1.0)

# Define the GP regression model
model = GPyOpt.models.GPModel(kernel=kernel, optimize_restarts=5, verbose=False)

# Define the acquisition optimizer
acquisition_optimizer = GPyOpt.optimization.AcquisitionOptimizer(design_space)

# Define the acquisition function
acquisition = GPyOpt.acquisitions.AcquisitionEI(model, design_space, optimizer=acquisition_optimizer, jitter=0.01)

# Define the Bayesian optimizer
bo = GPyOpt.methods.BayesianOptimization(f=F, 
                                         domain=design_space, 
                                         model=model, 
                                         acquisition=acquisition,
                                         acquisition_optimizer=acquisition_optimizer,
                                         initial_design_numdata=num_init_points)

# Optimize the function
max_iter = 10
bo.run_optimization(max_iter=max_iter)

# Print the best set of parameters and the corresponding function value
print("Best set of parameters: ", bo.x_opt)
print("Best function value: ", bo.fx_opt)
