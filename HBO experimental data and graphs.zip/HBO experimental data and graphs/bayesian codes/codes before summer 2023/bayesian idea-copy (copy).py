#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Jul 14 13:35:11 2023

@author: niloofar
"""

# -*- coding: utf-8 -*-
"""
my code after bayesian data collection


"""

import pandas as pd
from sklearn import datasets, linear_model
from sklearn.metrics import mean_squared_error, r2_score
from math import isnan
from statistics import mean
from sklearn.preprocessing import PolynomialFeatures
from sklearn.linear_model import LinearRegression
import pandas as pd
import numpy as np
import random
import matplotlib.pyplot as plt
import csv
import statistics
import math 
from sklearn.datasets import load_boston
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error, r2_score
from matplotlib import pyplot as plt
from matplotlib import pyplot as plt2
from matplotlib import pyplot as plt3
import os.path
from os import path
from matplotlib import rcParams
import datetime 
from datetime import datetime
from scipy.stats import linregress
import matplotlib as mpl


from matplotlib.pyplot import figure




def remove_duplicates(lst):
    seen = set()
    result = []

    for sublst in lst:
        subtuple = tuple(sublst)
        if subtuple not in seen:
            seen.add(subtuple)
            result.append(sublst)

    return result
plt.rcParams['font.size'] = '14.5'
plt.rcParams['lines.markersize'] = 5
plt.rcParams["font.family"] = "Times New Roman"
plt.rcParams["axes.labelweight"] = "bold"
plt.rcParams["figure.autolayout"] = True

lines=[  'dashed','-.',':', '--',   'solid', 'dotted', '',]
width=[2.5,4,2,3.5,3,3.5,4,4.5,5,5.5]

markers=['o','.','v','1','s','x','p','d']


path ='Bayesian_dataCollection19:19.csv' #this is for smoothed weights using the function with alpha=0.7 and windows of 3

data= pd.read_csv(path)

rt1=list(data['RT1'].values.reshape(-1,1)[:,0]) 
 
rt2=list(data['RT2'].values.reshape(-1,1)[:,0]) 

rt3=list(data['RT3'].values.reshape(-1,1)[:,0]) 

tris=list(data['Tris'].values.reshape(-1,1)[:,0]) 

avgQ=list(data['avgQ'].values.reshape(-1,1)[:,0]) 

dev1=list(data['Device1'].values.reshape(-1,1)[:,0]) 
dev2=list(data['Device2'].values.reshape(-1,1)[:,0]) 
dev3=list(data['Device3'].values.reshape(-1,1)[:,0]) 


model1=list(data['Model1'].values.reshape(-1,1)[:,0]) 
model2=list(data['Model2'].values.reshape(-1,1)[:,0]) 
model3=list(data['Model3'].values.reshape(-1,1)[:,0]) 


input_data=[]

utl_devices=[] # CPU utilization

for i in range (0,len(rt1)):
    utl_devices.append(  [((dev1[i].count("CPU")+ dev2[i].count("CPU") +dev3[i].count("CPU")) /3)  
   ,  ((dev1[i].count("GPU")+ dev2[i].count("GPU") +dev3[i].count("GPU")) /3 ) 
   ,  ((dev1[i].count("NNAPI")+ dev2[i].count("NNAPI") +dev3[i].count("NNAPI")) /3) ] )
    
    
for i in range (0,len(rt1)):
  input_data.append([round(utl_devices[i][0],1),round(utl_devices[i][1],1),round(utl_devices[i][2],1),round(tris[i]),round(avgQ[i],2)])  

import itertools
from operator import itemgetter
from operator import itemgetter

three_column_vals = list(map(itemgetter(0,1,2,3), input_data))         # [1, 3, 5]


uniqueInput=remove_duplicates(three_column_vals)



from bayes_opt import BayesianOptimization
from bayes_opt.util import UtilityFunction
from itertools import product

def objective_function(x1, x2, x3, x4):
    # Perform calculations based on the inputs and return the output value (y)
  
    if abs(x1 + x2 + x3 ) > 1:
      return -float('inf')  # Return negative infinity if the sum is not equal to 1
  
  
    y = 0.5*x4 + x1
    # Your calculations here
    return y



# Define the search space
x_values = [0, 0.3, 0.7, 1]
'''
x_combinations = [(x1, x2, x3) for x1 in x_values for x2 in x_values for x3 in x_values]
pbounds = {'x1': (0, len(x_combinations)-1),
           'x2': (0, len(x_combinations)-1),
           'x3': (0, len(x_combinations)-1),
           'x4': (43, 435)}
'''

x1_values = [0, 0.3, 0.7, 1]
x2_values = [0, 0.3, 0.7, 1]
x3_values = [0, 0.3, 0.7, 1]
x4_values = [43, 217, 435]

x_combinations=[]
for x4 in x4_values:
 for x1 in x1_values:
  for x2 in x2_values:
    for x3 in x3_values:
        if(x1+x2+x3==1):
           x_combinations.append([x1,x2,x3,x4])
#x_combinations = [(x1, x2, x3, x4) for x1 in x1_values for x2 in x2_values for x3 in x3_values for x4 in x4_values if x1+x2+x3=1]
pbounds={'x1': random.choice(x_values),'x2':  random.choice(x_values),'x3':  random.choice(x_values),
'x4':  random.choice(x4_values)}
pbounds = {'x1': (0,0.1),
           'x2': (0,0.5),
           'x3': (0, 0.4),
           'x4': (43, 435)}

'''
optimizer = BayesianOptimization(f=objective_function, pbounds=pbounds)

# Set the acquisition function
acquisition_function = UtilityFunction(kind='ucb', kappa=2.5, xi=0.01)

# Set the Gaussian process parameters and pass the acquisition function
optimizer.set_gp_params(alpha=1e-6, n_restarts_optimizer=5)

# Perform the optimization
optimizer.maximize(acquisition_function=acquisition_function, init_points=5, n_iter=10)

# Get the best input combination and the corresponding maximum value
best_input_combination = optimizer.max['params']
best_output_value = optimizer.max['target']

print("Best input combination:", best_input_combination)
print("Best output value:", best_output_value)
'''

# Initialize the Bayesian optimizer
optimizer = BayesianOptimization(f=objective_function, pbounds=pbounds,allow_duplicate_points=True)

# Set the Gaussian process parameters
optimizer.set_gp_params(alpha=1e-6, n_restarts_optimizer=5,)

# Set the acquisition function
acquisition_function = UtilityFunction(kind="ucb", kappa=2.5, xi=0.01)

# Define a function to exclude invalid combinations
def valid_combinations(x1, x2, x3):
    return x1 + x2 + x3 - 1

# Perform the optimization while excluding invalid combinations
optimizer.maximize(acquisition_function=acquisition_function, init_points=5, n_iter=10)
#  xi=0.01, valid_set=valid_combinations)

# Get the best input combination and the corresponding maximum value
best_input_combination = optimizer.max['params']
best_output_value = optimizer.max['target']

print("Best input combination:", best_input_combination)
print("Best output value:", best_output_value)




