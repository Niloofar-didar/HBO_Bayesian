#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Dec 14 00:19:59 2023

@author: niloofar
"""


"""
This is for graphs of HBO trigger
@author: niloofar
"""
import pandas as pd

from math import isnan
from statistics import mean
from sklearn.preprocessing import PolynomialFeatures
from sklearn.linear_model import LinearRegression
import pandas as pd
import numpy as np
import random
import matplotlib.pyplot as plt
import csv
import statistics
import math 
from sklearn.datasets import load_boston
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error, r2_score
from matplotlib import pyplot as plt
from matplotlib import pyplot as plt2
from matplotlib import pyplot as plt3
import os.path
from os import path
from matplotlib import rcParams
import datetime 
from datetime import datetime
from scipy.stats import linregress
import matplotlib as mpl

#mpl.rcParams['axes.formatter.useoffset'] = False

from matplotlib.pyplot import figure

'''stack graph for the best case'''
import matplotlib.pyplot as plt



col="#1874CD"
col2='#b3b3b3'
colors=[col, "#c1272d",'orange',"#008176"]

plt.rcParams['font.size'] = '20'
plt.rcParams['lines.markersize'] = 22
plt.rcParams["font.family"] = "Times New Roman"
plt.rcParams["axes.labelweight"] = "bold"
plt.rcParams["figure.autolayout"] = True


markers=['o', '.','1','s']


root="Quality21:37.csv"

hbo= pd.read_csv(root)

time=list(hbo['time'].values.reshape(-1,1)[:,0]) # 
bt=list(hbo['reward_bt'].values.reshape(-1,1)[:,0]) # 
hbo_running=list(hbo['hbo_running'].values.reshape(-1,1)[:,0]) # best_bt
best_bt=list(hbo['best_bt'].values.reshape(-1,1)[:,0]) # best_bt

rewards=[]
hbo_run=[]

indexes=[]


for i in range (2,len(bt)-1):
    if( hbo_running[i]==0 or(  hbo_running[i]==1 and hbo_running[i+1]==0)):
        indexes.append(i)
        hbo_run.append(hbo_running[i])
        rewards.append(bt[i])
        
for i in range (0,len(rewards)):       
        if(hbo_run[i]==1):
            print(i)
'''
for i in range (0,len(bt)-1):
    if(time[i]!=time[i+1] and best_bt[i]!=0   ): 
       #and hbo_running[i]==0):#hbo_running[i]==0 cause we don't want reward while running HBO

        if(hbo_running[i]==1 and hbo_running[i-1]==0):
           hbo_run.append(hbo_running[i])
           rewards.append(bt[i])
        elif(hbo_running[i]==0):
               rewards.append(bt[i])
               hbo_run.append(hbo_running[i])

indexes.append(5) #count the first trigger for the first object-> also 5%5==0
'''

time=list(range(1,len(rewards)+1) )   
fig, ax = plt.subplots() 
plt.plot(time ,rewards ,linestyle='none',marker=".",linewidth=1)   
#plt.plot(time[best_index] ,bReward[best_index] ,marker='x', markersize=9,label='Best', color='r',markeredgewidth=2) 
plt.xlabel('Time (s)')  
plt.ylabel('Reward') 
# Set the x-axis tick positions and labels
#plt.xticks(time)
ax.legend(loc="best", ncol=4,columnspacing=0.2,handletextpad=0.21,labelspacing = 0.14)#, fontsize=14) 
plt.tight_layout()
fig.savefig( "HBOrewardvsTime"+".pdf" )
