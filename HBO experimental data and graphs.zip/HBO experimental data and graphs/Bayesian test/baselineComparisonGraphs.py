#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
This is the comparison between bayesian and four baselines
baseline 1- match Quality + Static delegate
baseline2- match Latency + Static Delegate
baseline3- HBO without changing triangle count
baseline4- ALl NNAPI


Created on Tue Sep 19 21:48:45 2023

@author: niloofar
"""

from math import isnan
from statistics import mean
from sklearn.preprocessing import PolynomialFeatures
from sklearn.linear_model import LinearRegression
import pandas as pd
import numpy as np
import random
import matplotlib.pyplot as plt
import csv
import statistics
import math 
from sklearn.datasets import load_boston
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error, r2_score
from matplotlib import pyplot as plt
from matplotlib import pyplot as plt2
from matplotlib import pyplot as plt3
import os.path
from os import path
from matplotlib import rcParams
import datetime 
from datetime import datetime
from scipy.stats import linregress
import matplotlib as mpl

#mpl.rcParams['axes.formatter.useoffset'] = False

from matplotlib.pyplot import figure


plt.rcParams['font.size'] = '17'
plt.rcParams['lines.markersize'] = 10
plt.rcParams["font.family"] = "Times New Roman"
plt.rcParams["axes.labelweight"] = "bold"
plt.rcParams["figure.autolayout"] = True

'''
root="Sep2023/"
test=root+"@BYS and two baselines/Good-config 17 6 tasks 3meta 3 classlite 13 objs-baseline2 left"
series="10:46"
root="sep-AfterNormalization/"
test=root+"conf18 -sc9 - 2CPU and 4 N check improvement"
series="13:10"
'''

root="sep-AfterNormalization/"
test=root+"FINAL conf new-sc9"
series="18:16"

baseAllN_data= pd.read_csv(str(test)+"/allNNAPI.csv" )
bayesNoTris_out=pd.read_csv(str(test)+"/Bayesian OUTPUTNoTris.csv" )#
bayesNoTris_data= pd.read_csv(str(test)+"/bayesNoTris.csv" )#bayesian3 without Triangle change
bayes_data= pd.read_csv(str(test)+"/Bayesian_dataCollection"+str(series)+".csv")  # data of app for bayesian
python_bayes_data= pd.read_csv(str(test)+"/Bayesian OUTPUT"+str(series)+".csv")  
baseDat12= pd.read_csv(str(test)+"/Static_dataCollection"+str(series)+".csv") 

cpubaseDat12= pd.read_csv(str(test)+"/CPU_Mem_Base12"+".csv")  
cpubayes_data= pd.read_csv(str(test)+"/CPU_Mem_"+str(series)+".csv") 
cpuNotDat= pd.read_csv(str(test)+"/CPU_Mem_noTris"+".csv")  
cpuAllNdata= pd.read_csv(str(test)+"/CPU_Mem_AllNNAPI"+".csv") 

avgQBYS=list(bayes_data['avgQ'].values.reshape(-1,1)[:,0]) #

## data of bayesian fetched
bYReward=list(python_bayes_data['reward'].values.reshape(-1,1)[:-2,0]) # 
ttris=list(python_bayes_data['ttris'].values.reshape(-1,1)[:-2,0]) # 
cu=list(python_bayes_data['cu'].values.reshape(-1,1)[:-2,0]) # cpu usage
gu=list(python_bayes_data['gu'].values.reshape(-1,1)[:-2,0]) # Gpu usage
nu=list(python_bayes_data['nu'].values.reshape(-1,1)[:-2,0]) # NNAPI usage
tris_ratio=list(python_bayes_data['tris'].values.reshape(-1,1)[:-2,0]) # 
ct=list(python_bayes_data['ct'].values.reshape(-1,1)[:-2,0]) # traslated cpu usage
gt=list(python_bayes_data['gt'].values.reshape(-1,1)[:-2,0]) # 
nt=list(python_bayes_data['nt'].values.reshape(-1,1)[:-2,0]) # 
ttris=list(python_bayes_data['ttris'].values.reshape(-1,1)[:-2,0]) # 

models=[]
models.append(list(bayes_data['Model1'].values.reshape(-1,1)[:-2,0])[0]) # 
models.append(list(bayes_data['Model2'].values.reshape(-1,1)[:-2,0])[0]) # 
models.append(list(bayes_data['Model3'].values.reshape(-1,1)[:-2,0])[0]) # 
models.append(list(bayes_data['Model4'].values.reshape(-1,1)[:-2,0])[0]) # 
models.append(list(bayes_data['Model5'].values.reshape(-1,1)[:-2,0])[0]) # 
models.append(list(bayes_data['Model6'].values.reshape(-1,1)[:-2,0])[0]) # 

for i in range(0, len( models)):
    if (str(models[i])==( "model_metadata")):
        models[i]="mmdata"
    elif (str(models[i])==( "mobilenetDetv1")):
        models[i]="mobnetD1"

    elif (str(models[i])==( "efficientclass-lite0")):
        models[i]="class-lite0"
        
    elif (str(models[i])==( "mobilenetClassv1")):
        models[i]="mobnetC1"        
        
        
        
        
best_iteration=bYReward.index(max(bYReward))+1# this is for data2 
best_index_py=best_iteration-1 # index of best of BAYESIAN OUTPUT python result
avgQBY=avgQBYS[best_iteration]

## data of baseline1-2 fetched
ttrisBase12=list(baseDat12['selectedTRatio'].values.reshape(-1,1)[:,0]) # 
percErBase12=list(baseDat12['percentageError'].values.reshape(-1,1)[:,0]) # 
avgQBs=list(baseDat12['avgQ'].values.reshape(-1,1)[:,0]) # 
basedevices12=[]
basedevices12.append(list(baseDat12['Device1'].values.reshape(-1,1)[:,0])[0])
basedevices12.append(list(baseDat12['Device2'].values.reshape(-1,1)[:,0])[0])
basedevices12.append(list(baseDat12['Device3'].values.reshape(-1,1)[:,0])[0])
basedevices12.append(list(baseDat12['Device4'].values.reshape(-1,1)[:,0])[0])
basedevices12.append(list(baseDat12['Device5'].values.reshape(-1,1)[:,0])[0])
basedevices12.append(list(baseDat12['Device6'].values.reshape(-1,1)[:,0])[0])
tRatiobs2=list(baseDat12['selectedTRatio'].values.reshape(-1,1)[:,0])




## data of allNNAPI baseline fetched
basedevicesAllN=[]
basedevicesAllN.append(list(baseAllN_data['Device1'].values.reshape(-1,1)[:,0])[0])
basedevicesAllN.append(list(baseAllN_data['Device2'].values.reshape(-1,1)[:,0])[0])
basedevicesAllN.append(list(baseAllN_data['Device3'].values.reshape(-1,1)[:,0])[0])
basedevicesAllN.append(list(baseAllN_data['Device4'].values.reshape(-1,1)[:,0])[0])
basedevicesAllN.append(list(baseAllN_data['Device5'].values.reshape(-1,1)[:,0])[0])
basedevicesAllN.append(list(baseAllN_data['Device6'].values.reshape(-1,1)[:,0])[0])
tRatioAllN=list(baseAllN_data['selectedTRatio'].values.reshape(-1,1)[:,0])[0]
latencyAllN=[]
latencyAllN.append(list(baseAllN_data['Latency1'].values.reshape(-1,1)[:,0]))
latencyAllN.append(list(baseAllN_data['Latency2'].values.reshape(-1,1)[:,0]))
latencyAllN.append(list(baseAllN_data['Latency3'].values.reshape(-1,1)[:,0]))
latencyAllN.append(list(baseAllN_data['Latency4'].values.reshape(-1,1)[:,0]))
latencyAllN.append(list(baseAllN_data['Latency5'].values.reshape(-1,1)[:,0]))
latencyAllN.append(list(baseAllN_data['Latency6'].values.reshape(-1,1)[:,0]))
avgQAllN=1

## data of baseline3-NoTris fetched
noTrisReward=list(bayesNoTris_out['reward'].values.reshape(-1,1)[:-2,0]) # 

best_iterationN0tris=noTrisReward.index(max(noTrisReward))+1# this is for data2 
iterationN0tris=list(bayesNoTris_data['iteration'])
fBest_IterationNoT=iterationN0tris.index(best_iterationN0tris) #THIS IS FOR BAYESIAN MAIN FILE first index of best iteration
lBest_IterationNoT=len(iterationN0tris) - iterationN0tris[::-1].index(best_iterationN0tris) - 1 # last index of best iteration


basedevicesNoTris=[]
basedevicesNoTris.append(list(bayesNoTris_data['Device1'].values.reshape(-1,1)[:,0])[fBest_IterationNoT])
basedevicesNoTris.append(list(bayesNoTris_data['Device2'].values.reshape(-1,1)[:,0])[fBest_IterationNoT])
basedevicesNoTris.append(list(bayesNoTris_data['Device3'].values.reshape(-1,1)[:,0])[fBest_IterationNoT])
basedevicesNoTris.append(list(bayesNoTris_data['Device4'].values.reshape(-1,1)[:,0])[fBest_IterationNoT])
basedevicesNoTris.append(list(bayesNoTris_data['Device5'].values.reshape(-1,1)[:,0])[fBest_IterationNoT])
basedevicesNoTris.append(list(bayesNoTris_data['Device6'].values.reshape(-1,1)[:,0])[fBest_IterationNoT])

latencyNoTris=[]
latencyNoTris.append(list(bayesNoTris_data['Latency1'].values.reshape(-1,1)[fBest_IterationNoT:lBest_IterationNoT+1,0]))
latencyNoTris.append(list(bayesNoTris_data['Latency2'].values.reshape(-1,1)[fBest_IterationNoT:lBest_IterationNoT+1,0]))
latencyNoTris.append(list(bayesNoTris_data['Latency3'].values.reshape(-1,1)[fBest_IterationNoT:lBest_IterationNoT+1,0]))
latencyNoTris.append(list(bayesNoTris_data['Latency4'].values.reshape(-1,1)[fBest_IterationNoT:lBest_IterationNoT+1,0]))
latencyNoTris.append(list(bayesNoTris_data['Latency5'].values.reshape(-1,1)[fBest_IterationNoT:lBest_IterationNoT+1,0]))
latencyNoTris.append(list(bayesNoTris_data['Latency6'].values.reshape(-1,1)[fBest_IterationNoT:lBest_IterationNoT+1,0]))

tRatioNoTris=1
avgQNoTris=1



'''compare the latency data'''
columns = ['Actual_RT1',  'Actual_RT2', 
           'Actual_RT3',  'Actual_RT4', 
           'Actual_RT5',  'Actual_RT6']

iteration=list(bayes_data['iteration'])
fBest_Iteration_index=iteration.index(best_iteration) #THIS IS FOR BAYESIAN MAIN FILE first index of best iteration

lBest_Iteration_index=len(iteration) - iteration[::-1].index(best_iteration) - 1 # last index of best iteration


latencyBY = {}
latencyBS1 = {}
nrm_latency = {}
latencyBS2={}

latencyBSalN={}
latencyBSNoTr={}

'''this is for CPU overhead'''
lastbase1Indx=ttrisBase12.index(1)
cpu_tRatiobs2=list(cpubaseDat12['selectedTRatio'].values.reshape(-1,1)[:,0])
cpuUbase1L= list(cpubaseDat12['%CPU'].values.reshape(-1,1)[0:lastbase1Indx,0]) # the cpu usage log for matchQ experiment

cpuUbysL= list(cpubayes_data['%CPU'].values.reshape(-1,1)[:,0])
cpuIter= list(cpubayes_data['iteration'].values.reshape(-1,1)[:,0])
fIndxCPUBY=cpuIter.index(best_iteration)
lIndxCPUBY=len(cpuIter) - cpuIter[::-1].index(best_iteration) - 1 # last index of best iteration
#the cpu usage log for the best iteration of bayesian
cpuUBYSL=cpuUbysL[fIndxCPUBY:lIndxCPUBY+1]


cpuUAllNL= list(cpuAllNdata['%CPU'].values.reshape(-1,1)[0:lastbase1Indx,0]) 

cpuUNot= list(cpuNotDat['%CPU'].values.reshape(-1,1)[:,0])
cpuIter= list(cpuNotDat['iteration'].values.reshape(-1,1)[:,0])
fIndxCPU=cpuIter.index(best_iterationN0tris)
lIndxCPU=len(cpuIter) - cpuIter[::-1].index(best_iterationN0tris) - 1 # last index of best iteration
#the cpu usage log for the best iteration of bayesian
cpuUNotL=cpuUNot[fIndxCPU:lIndxCPU+1]

cpuULISTS=[mean(cpuUBYSL), mean(cpuUbase1L), mean(cpuUNotL), mean(cpuUAllNL)]



period=list(range(1,len(cpuUBYSL)+1) )  
'''
fig, ax = plt.subplots()  
ax.plot(period ,cpuUBYSL ,linestyle='solid',markersize=6,label='HBO') 
ax.plot(period ,cpuUbase1L ,linestyle='dashed',markersize=6,label='SMQ') 
ax.plot(period ,cpuUNotL ,linestyle='dashed',markersize=6,label='BNT')
ax.plot(period ,cpuUAllNL ,linestyle='dashed',markersize=6,label='ALLN')
'''
fig, ax = plt.subplots()
bar_labels=['HBO','SMQ','BNT','ALLN']
# Calculate the X-coordinate positions for the bars
x_positions= np.arange(0, len(cpuULISTS) * 1, 1)

legend_labels = []
bar_width = 0.5  # Adjust the width of the bars as needed

col="#1874CD"

#col2='#b3b3b3'
col2='#A9A9A9'
colors=[col,"Gray","#c1272d", "#0000a7","#eecc16","#008176"]

for k in range(len(cpuULISTS)):
    x_pos = x_positions[k]
    value = cpuULISTS[k]
   
    ax.bar(x_pos, value, width=bar_width,color=colors[k+1])
  
    # Add labels to the list for the legend
    #legend_labels.extend([f'HBO', f'MQ'])

# Get the legend handles and labels from both axes
#lines, _ = ax.get_legend_handles_labels()
#legend = ax.legend(lines , legend_labels, loc="lower right",handlelength=0.8 ,handletextpad=0.3,bbox_to_anchor=(1.02, 0.0),ncol=2)
ax.set_xticks(x_positions   )
ax.set_xticklabels(bar_labels)
#ax.set_xlabel('Period (2s)')  
ax.set_ylabel('Average CPU Usage (%)') 

#ax.legend(loc="best", ncol=4,columnspacing=0.2,handletextpad=0.21,labelspacing = 0.14)#, fontsize=14) 
plt.tight_layout()

fig.savefig( str(test)+"/CPU_UsageComparison"+".pdf" )



'''this is for match latency'''

matchLtcyIndx=percErBase12.index(min(percErBase12))
first_index_baseline2=ttrisBase12.index((ttrisBase12[matchLtcyIndx]))
last_index_baseline2 = len(ttrisBase12) - ttrisBase12[::-1].index(ttrisBase12[matchLtcyIndx]) - 1

print("ratio is"+ str(ttrisBase12[first_index_baseline2]))
#end_ratio_index= matchLtcyIndx+7

avgqBaseline2=avgQBs[matchLtcyIndx]
avgqBayes=avgQBYS[fBest_Iteration_index]
avgqBaseline1=avgqBayes

'''3- improvement in latency of HBO vs other baselines - need to calculate Task by Task improvement and then take the average and Sd to show the bargraphs'''


####this is for match latency
tasks = ['AI1',  'AI2', 
           'AI3',  'AI4', 
           'AI5',  'AI6']
j=0
for col in columns:
    actualT_BYS = bayes_data[col][fBest_Iteration_index:lBest_Iteration_index+1].values
    expectedT_BYS = bayes_data[col.replace('Actual', 'Expected')][fBest_Iteration_index:lBest_Iteration_index+1].values
    latencyBY[tasks[j]] = (actualT_BYS - expectedT_BYS).tolist()
    
    #nrm_latency[col]= ( (actualT_BYS - expectedT_BYS)/actualT_BYS  ).tolist()
    actualT_B1 = baseDat12[col][0:lastbase1Indx].values
    expectedT_B1 = baseDat12[col.replace('Actual', 'Expected')][0:lastbase1Indx].values
    latencyBS1[tasks[j]] = (actualT_B1 - expectedT_B1).tolist()

## this is for baseline2 match latency comparison
    actualT_B2 = baseDat12[col][first_index_baseline2:last_index_baseline2+1].values
    expectedT_B2 = baseDat12[col.replace('Actual', 'Expected')][first_index_baseline2:last_index_baseline2+1].values
    latencyBS2[tasks[j]] = (actualT_B2 - expectedT_B2).tolist()

    j+=1



sum_nrm_last=0
improvement1R={}# ratio of improvement vs baseline 1
improvement2R={} # vs baseline2
improvementNotR={} # vs baseline2
improvementAllNR={} # vs baseline2

meanIndvLatency_bys=[]
meanIndvLatency_b2=[]
k=0       
for j in tasks:
    
    listBY =(latencyBY[j])
    listB1 =(latencyBS1[j] )
    listB2=(latencyBS2[j])
    listB3=(latencyNoTris[k])
    listB4=(latencyAllN[k])
    #listNotris=latencyN
    #improvement1R[j] = listB1/listBY
    #improvement2R[j] = listB2/listBY
    improvement1R[j] =[x / y for x, y in zip(listB1, listBY)]
    improvement1R[j]=mean(  improvement1R[j])# this is to get average across all periods of data collection
   
    improvement2R[j] =[x / y for x, y in zip(listB2, listBY)]
    improvement2R[j]=mean(  improvement2R[j])
   
    improvementNotR[j] =[x / y for x, y in zip(listB3, listBY)]
    improvementNotR[j]=mean(  improvementNotR[j])
 
    improvementAllNR[j] =[x / y for x, y in zip(listB4, listBY)]
    improvementAllNR[j]=mean(  improvementAllNR[j])
    k+=1
 
    meanIndvLatency_bys.append(mean(latencyBY[j]))
    meanIndvLatency_b2.append(mean(latencyBS1[j])   )   # this has the best baseline                
 
     
improvementAllNRList = list(improvementAllNR.values())
improvementNotRList= list(improvementNotR.values())
improvement1RList= list(improvement1R.values())
improvement2RList= list(improvement2R.values())


'''graphs of ratio improvement or the ratio latency of baselines over HBO  '''

bar_labels = [ 'SMQ','SML','BNT','AllN'] ### matchQ, matchL, bayesian No tris, allnnapi

# Calculate means and standard deviations for each list
means = [np.mean(improvement1RList), np.mean(improvement2RList), np.mean(improvementNotRList), np.mean(improvementAllNRList)]
std_devs = [np.std(improvement1RList), np.std(improvement2RList), np.std(improvementNotRList), np.std(improvementAllNRList)]

# X-axis positions for the bars
x = np.arange(len(bar_labels))
time=[[1]]*len(x)
# Bar width
width = 0.5

# Create the bar graph
fig, ax = plt.subplots()
rects1 = ax.bar(x, means, width, yerr=std_devs, capsize=5, color="gray")
ax.plot(x,time,color='red', label='Ratio = 1 ')
# Add labels, title, and legend
ax.set_ylabel('Latency Ratio over HBO')

ax.set_xticks(x)
ax.set_xticklabels(bar_labels)
ax.legend()

# Display the graph
plt.tight_layout()
plt.show()
fig.savefig( str(test)+"/LatencyRatiovsBaselines"+".png" , dpi=300)






####1- delegate graph

# Initialize dictionaries to count each element


element_counts = {'CPU': 0, 'GPU': 0, 'NNAPI': 0}
delegatebs12=[]   
delegateNoTris=[] 
delegateAllN=[] 
for element in ['CPU', 'GPU', 'NNAPI']:
    count = basedevices12.count(element)
    delegatebs12.append(count)
    
    count = basedevicesAllN.count(element)
    delegateAllN.append(count)
    
    count = basedevicesNoTris.count(element)
    delegateNoTris.append(count)
    

delegateby=[ct[best_iteration-1],gt[best_iteration-1],nt[best_iteration-1]]    

#tratioBs2=   tRatiobs2[len(tRatiobs2)-1] 

# Labels for the bars
bar_labels = ['HBO', 'SMQ','SML','BNT','AllN'] ### matchQ, matchL, bayesian No tris, allnnapi

# Values for the bars
bar_values = [delegateby,delegatebs12,delegatebs12,delegateNoTris,delegateAllN]

# Colors for each component of the first stacked bar
component_colors = [ 'orange','gainsboro', 'gray']
pattern = ['', '.', '|','o','/',',']
fig, ax = plt.subplots()

# Create the first stacked bar with components
cc=0
cg=0
cn=0
delegateLabl=['CPU', 'GPU', 'NNAPI']
for k in range (0,len(bar_values)):
  bottom = 0
  curV=  bar_values[k]
  for i, value in enumerate(curV):
    if(delegateLabl[i]=="CPU" and cc==0):
      ax.bar(bar_labels[k], value, bottom=bottom, label=delegateLabl[i],hatch=pattern[i],color=component_colors[i])
      cc=1
    elif(delegateLabl[i]=="GPU" and cg==0):
        ax.bar(bar_labels[k], value, bottom=bottom, label=delegateLabl[i],hatch=pattern[i],color=component_colors[i])
        cg=1
    elif(delegateLabl[i]=="NNAPI" and cn==0):
      ax.bar(bar_labels[k], value, bottom=bottom, label=delegateLabl[i],hatch=pattern[i],color=component_colors[i])
      cn=1
    else:
        ax.bar(bar_labels[k], value, bottom=bottom,hatch=pattern[i],color=component_colors[i])
       
    bottom += value

# Add labels and title
#plt.xlabel('Delegate per ')
plt.ylabel('# of Tasks')
#plt.title('Stacked and Individual Bar Graph')
# Add legend for the components in the first bar
ax.legend(loc='upper right')
# Show the plot
plt.show()
fig.savefig( str(test)+"/DelegatevsBaselines"+".png" , dpi=300)


###2- Average Q vs Triangle Ratio
tratioBy= ttris[best_iteration-1]
tratioBs1=  tratioBy 
tratioBs2=  ttrisBase12[first_index_baseline2] 
tRATIO_bar_values = [tratioBy,tratioBs1,tratioBs2,tRatioNoTris,tRatioAllN]


avgQ_bar_values=[avgqBayes,avgqBaseline1,avgqBaseline2 ,avgQNoTris,avgQAllN]

second_bar_color = 'gray'


fig, ax = plt.subplots()
ax2 = ax.twinx()

# Calculate the X-coordinate positions for the bars
x_positions = np.arange(len(bar_labels))
legend_labels = []
bar_width = 0.4  # Adjust the width of the bars as needed
col="#1874CD"
col2="#B6D0E2"
#col3='gainsboro'
for k in range(len(bar_labels)):
    x_pos = x_positions[k]
    label = bar_labels[k]
    if(k==0):
      ax.bar(x_pos, tRATIO_bar_values[k], width=bar_width,color=col,label='T Ratio')
      ax2.bar(x_pos + bar_width, avgQ_bar_values[k], width=bar_width, color=col2, hatch='|',label='Average Quality')
    else:
       ax.bar(x_pos, tRATIO_bar_values[k], width=bar_width,color=col)
       ax2.bar(x_pos + bar_width, avgQ_bar_values[k], width=bar_width, color=col2, hatch='|')
  
    # Add labels to the list for the legend
    legend_labels.extend([f'T Ratio', f'Average Quality'])

ax.set_ylabel('Triangle Count Ratio (0-1)')
ax2.set_ylabel('Average Quality (0-1)')

# Get the legend handles and labels from both axes
lines, _ = ax.get_legend_handles_labels()
lines2, _ = ax2.get_legend_handles_labels()

# Create a combined legend with labels from both axes
legend = ax.legend(lines + lines2, legend_labels, loc="lower right",handlelength=0.8 ,handletextpad=0.3,bbox_to_anchor=(1.02, 0.0),ncol=2)
legend2 = ax2.legend(lines + lines2, legend_labels, loc="lower right",handlelength=0.8,handletextpad=0.3 ,bbox_to_anchor=(1.02, 0.0),ncol=2)
    
plt.xticks(rotation=45, fontsize=12)
# Set the X-axis labels and positions
ax.set_xticks(x_positions + bar_width / 2)
ax.set_xticklabels(bar_labels)

fig.savefig( str(test)+"/TrisRvsAvgQ_vsBaselines"+".png" , dpi=300)



avgQ=list(bayes_data['avgQ'].values.reshape(-1,1)[:,0]) # 
avgL=list(bayes_data['avgLatency'].values.reshape(-1,1)[:,0]) # 
reward=[]
nor_latency=[]

last_iter=iteration[len(iteration) -1]
bayes_latency_iter=[]
bayes_avgQ_iter=[]
for i in range(1,last_iter+1):
    
    firstIndx=iteration.index(i)
    lastIndx=len(iteration) - iteration[::-1].index(i) - 1 # last index of best iteration
    bayes_latency_iter.append(avgL[lastIndx]) #cause this one has the average of the last 5 period
    bayes_avgQ_iter.append(avgQ[lastIndx])

time=list(range(1,len(bayes_avgQ_iter)+1) )   
fig, ax = plt.subplots()  
ax2 = ax.twinx()

ax.plot(time ,bayes_avgQ_iter ,linestyle='none',marker="*",markersize=6)   
ax.plot(best_iteration ,bayes_avgQ_iter[best_iteration] ,marker='x', markersize=9,label='Best', color='r',markeredgewidth=2) 
ax2.plot(time ,bayes_latency_iter ,linestyle='none',marker="o",markersize=3,color='r')  
ax.set_xlabel('Iteration')  
ax.set_ylabel('Average Quality (0-1)') 
ax2.set_ylabel('Norm. Average Latency',color='r') 
#ax2.set_ylabel('Average Latency($10^{2}$ ms)',color='r') 
ax.legend(loc="best", ncol=4,columnspacing=0.2,handletextpad=0.21,labelspacing = 0.14)#, fontsize=14) 
plt.tight_layout()
minY=min(min(bayes_avgQ_iter,bayes_latency_iter))
ax.set_ylim(minY-0.1,1.1)
ax2.set_ylim(minY-0.1,1.1)
fig.savefig( str(test)+"/Latency_Quality_detail"+".pdf" )



''' this is for in detail latency improvement'''

#compare the latency data for bayesian vs four baselines

# for Tratio stack graph
bar_labels = models
#['AI1', 'AI2','AI3','AI4', 'AI5','AI6']
bar_values1 =meanIndvLatency_bys
bar_values2=meanIndvLatency_b2
second_bar_color = 'gray'

'''this is the twinx'''

fig, ax = plt.subplots()

# Calculate the X-coordinate positions for the bars
x_positions= np.arange(0, len(bar_labels) * 4, 4)

legend_labels = []
bar_width = 1.5  # Adjust the width of the bars as needed

col="#1874CD"
col2='#b3b3b3'

colors=[col, col2,"#c1272d","#0000a7","#eecc16","#008176","#B6D0E2"]

for k in range(len(bar_labels)):
    x_pos = x_positions[k]
    label = bar_labels[k]
    if(k==0):
      ax.bar(x_pos, bar_values1[k], width=bar_width,color=colors[2],label='HBO')
      ax.bar(x_pos + bar_width, bar_values2[k], width=bar_width, color=colors[6], hatch=pattern[2],label='MQ')
    else:
       ax.bar(x_pos, bar_values1[k], width=bar_width,color=colors[2])
       ax.bar(x_pos + bar_width, bar_values2[k], width=bar_width, color=colors[6], hatch=pattern[2])
  
    # Add labels to the list for the legend
    legend_labels.extend([f'HBO', f'SMQ'])

ax.set_ylabel('Average Latency (ms)')
maxval=max(max(bar_values1,bar_values2))
ax.set_ylim(0,maxval+10)

# Get the legend handles and labels from both axes
lines, _ = ax.get_legend_handles_labels()

legend = ax.legend(lines , legend_labels, loc="lower right",handlelength=0.8 ,handletextpad=0.3,bbox_to_anchor=(1.02, 0.0),ncol=2)

ax.set_xticks(x_positions + bar_width / 2  )
ax.set_xticklabels(bar_labels,rotation=17)
fig.savefig( str(test)+"/Latency_cimparison_detail"+".pdf" )

perc_diff=[]
for i in range (0,len(bar_values1)):
    
    hbo=bar_values1[i]
    
    base1=bar_values2[i]
    perc_diff.append((hbo-base1)/hbo)
