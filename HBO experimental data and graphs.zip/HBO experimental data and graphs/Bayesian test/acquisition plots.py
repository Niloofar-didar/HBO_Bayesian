#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Sep 24 20:03:32 2023

@author: niloofar
"""
from pylab import savefig
from math import isnan
from statistics import mean
from sklearn.preprocessing import PolynomialFeatures
from sklearn.linear_model import LinearRegression
import pandas as pd
import numpy as np
import random
import matplotlib.pyplot as plt
import matplotlib.pyplot as plt1
import csv
import statistics
import math 
from sklearn.datasets import load_boston
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error, r2_score
from matplotlib import pyplot as plt
from matplotlib import pyplot as plt2
from matplotlib import pyplot as plt3
import os.path
from os import path
from matplotlib import rcParams
import datetime 
from datetime import datetime
from scipy.stats import linregress
import matplotlib as mpl

#mpl.rcParams['axes.formatter.useoffset'] = False

from matplotlib.pyplot import figure

col="#1874CD"
col2='#b3b3b3'
colors=[col, "#c1272d",'orange',"#008176"]

plt.rcParams['font.size'] = '17'
plt.rcParams['lines.markersize'] = 10
plt.rcParams["font.family"] = "Times New Roman"
plt.rcParams["axes.labelweight"] = "bold"
plt.rcParams["figure.autolayout"] = True


markers=['o', '.','1','s']
def test_plot_convergence(inputdata, minReward ,  filename,name):
    
    
 
    #Plots to evaluate the convergence of standard Bayesian optimization algorithms
  #plt.figure(figsize=(6,4.5))
  fig, ax = plt.subplots()  
  plt.subplot(1,1,1)
  best_Y2=[]
  for i in range(0,len(inputdata)):
    Xdata=   inputdata[i]
    best_Y2.append(minReward[i])
    n = Xdata.shape[0]
    aux = (Xdata[1:n,:]-Xdata[0:n-1,:])**2
    distances = np.sqrt(aux.sum(axis=1))
    ## Distances between consecutive x's

    plt.plot(list(range(1,n)), distances, '-ro',label=name[i])
    plt.xlabel('Iteration')
    #plt.ylabel('d(x[n], x[n-1])')
    plt.ylabel('Distance between trials')
    plt.grid(True)
    #plt.xlim(0,len(best_Y)+1)
    #plt.title('Distance between consecutive x\'s')
    #grid(True)
    plt.legend(loc="best")
    if filename!=None:
        savefig( str(filename)+"dis.pdf" , dpi=300)
        
    else:
        plt.show()

    # Estimated m(x) at the proposed sampling points
  #plt.figure(figsize=(6,4.3))
  #
  fig, ax = plt.subplots() 
  #plt.subplot(1,1,1)
  for i in range(0,len(inputdata)):
    Xdata=   inputdata[i]
    best_Y=(minReward[i])
    n = Xdata.shape[0]
   
    plt.plot(list(range(1,n+1)),best_Y,marker=markers[i],label=name[i],color=colors[i])
    #plt.title('Value of the best selected sample')
    #plt.ylim(0.7,max(best_Y)+0.05)
    plt.ylim(min(best_Y2[3])-0.15,max(best_Y2[1])+0.1)
  plt.xlabel('Iteration')
  plt.ylabel('Best Cost')
  plt.grid(True)
  plt.legend(loc="best",ncol=2)
  #plt.ylim(min(best_Y)-0.05,max(best_Y)+0.05)  
  if filename!=None:
        savefig( str(filename)+".pdf" , dpi=300)
        #savefig(filename+"distance")
  else:
        plt.show()
        
   
   
def test_plot_convergence_single(inputdata,minReward , filename=None):
    
    #Plots to evaluate the convergence of standard Bayesian optimization algorithms
 
  for i in range(0,len(inputdata)):
    Xdata=   inputdata[i]
    best_Y=minReward[i]
    n = Xdata.shape[0]
    aux = (Xdata[1:n,:]-Xdata[0:n-1,:])**2
    distances = np.sqrt(aux.sum(axis=1))

    ## Distances between consecutive x's
    plt.figure(figsize=(6,4.5))
    plt.subplot(1,1,1)
    #plt.subplot(1, 2, 1)
   
    #fig, ax = plt.subplots()
    #plt.plot(list(range(n-1)), distances, '-ro')
    plt.plot(list(range(1,n)), distances, '-ro')
    plt.xlabel('Iteration')
    #plt.ylabel('d(x[n], x[n-1])')
    plt.ylabel('Distance between trials')
    plt.grid(True)
    #plt.xlim(0,len(best_Y)+1)
    #plt.title('Distance between consecutive x\'s')
    #grid(True)
   
    if filename!=None:
        savefig( str(filename)+"dis.pdf" , dpi=300)
        
    else:
        plt1.show()

    # Estimated m(x) at the proposed sampling points
    #plt.subplot(1, 2, 2)
    #fig, ax = plt.subplots()
    plt.figure(figsize=(6,4.5))
    #plt.subplot(1, 2, 1)
    plt.subplot(1,1,1)
    plt.plot(list(range(1,n+1)),best_Y,'-o')
    #plt.title('Value of the best selected sample')
    #plt.ylim(0.7,max(best_Y)+0.05)
    plt.ylim(min(best_Y)-0.05,max(best_Y)+0.05)
    plt.xlabel('Iteration')
    plt.ylabel('Best Cost')
    plt.grid(True)

    if filename!=None:
        savefig( str(filename)+".pdf" , dpi=300)
        #savefig(filename+"distance")
    else:
        plt.show()
                
   
    

plt.rcParams['font.size'] = '17'
plt.rcParams['lines.markersize'] = 10
plt.rcParams["font.family"] = "Times New Roman"
plt.rcParams["axes.labelweight"] = "bold"
plt.rcParams["figure.autolayout"] = True




root="sep-AfterNormalization/"
test=root+"experiment 1- four sc_cf/"


test1=test+"/exp1_sc1cf1"##= sc1-1
test2=test+"/exp1_sc9cf1" #= sc2conf1
test3=test+"/exp1_sc9cf2" #=sc2conf2
test4=test+"/exp1_sc1cf2" #

series1="18:16"
series2="10:34"
series3="15:15"
series4="14:39"

name=["SC1-CF1", "SC2-CF1","SC1-CF2","SC2-CF2"]
tests=[test1,test2,test4,test3]
series=[series1,series2,series4,series3 ]
minRewards=[]
input_data=[]

for r in range(0,len(tests)):
    

  k=r+1
  finalD=tests[r]
  finalS=series[r]

  python_bayes_data= pd.read_csv(str(finalD)+"/Bayesian OUTPUT"+str(finalS)+".csv")  


## data of bayesian fetched
  bYReward=list(python_bayes_data['reward'].values.reshape(-1,1)[:-2,0]) # 
  ttris=list(python_bayes_data['ttris'].values.reshape(-1,1)[:-2,0]) # 
  cu=list(python_bayes_data['cu'].values.reshape(-1,1)[:-2,0]) # cpu usage
  gu=list(python_bayes_data['gu'].values.reshape(-1,1)[:-2,0]) # Gpu usage
  nu=list(python_bayes_data['nu'].values.reshape(-1,1)[:-2,0]) # NNAPI usage
  tris_ratio=list(python_bayes_data['tris'].values.reshape(-1,1)[:-2,0]) # 
  ct=list(python_bayes_data['ct'].values.reshape(-1,1)[:-2,0]) # traslated cpu usage
  gt=list(python_bayes_data['gt'].values.reshape(-1,1)[:-2,0]) # 
  nt=list(python_bayes_data['nt'].values.reshape(-1,1)[:-2,0]) # 
  ttris=list(python_bayes_data['ttris'].values.reshape(-1,1)[:-2,0]) # 

  for i in range(0,len(bYReward)):
    bYReward[i]*=-1


  input_data.append( np.column_stack((cu, gu, nu, ttris)))

  minReward=[]
  min_value = float('inf')

  for reward in bYReward:
    min_value = min(min_value, reward)  # Calculate the minimum up to the current index
    minReward.append(min_value)  # Append the minimum to the new list

  minRewards.append(minReward)
#print(minReward)

test_plot_convergence(input_data,minRewards,finalD+"/convergence_plot",name)
#test_plot_convergence(input_data,minRewards,filename=finalD+"/convergence_plot"+str(k),name)
