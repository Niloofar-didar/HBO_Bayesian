#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
This is the comparison between bayesian and four baselines
baseline 1- match Quality + Static delegate
baseline2- match Latency + Static Delegate
baseline3- HBO without changing triangle count
baseline4- ALl NNAPI


Created on Tue Sep 19 21:48:45 2023

@author: niloofar
"""

from math import isnan
from statistics import mean
from sklearn.preprocessing import PolynomialFeatures
from sklearn.linear_model import LinearRegression
import pandas as pd
import numpy as np
import random
import matplotlib.pyplot as plt
import csv
import statistics
import math 
from sklearn.datasets import load_boston
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error, r2_score
from matplotlib import pyplot as plt
from matplotlib import pyplot as plt2
from matplotlib import pyplot as plt3
import os.path
from os import path
from matplotlib import rcParams
import datetime 
from datetime import datetime
from scipy.stats import linregress
import matplotlib as mpl

#mpl.rcParams['axes.formatter.useoffset'] = False

from matplotlib.pyplot import figure


plt.rcParams['font.size'] = '17'
plt.rcParams['lines.markersize'] = 10
plt.rcParams["font.family"] = "Times New Roman"
plt.rcParams["axes.labelweight"] = "bold"
plt.rcParams["figure.autolayout"] = True

'''
root="Sep2023/"
test=root+"@BYS and two baselines/Good-config 17 6 tasks 3meta 3 classlite 13 objs-baseline2 left"
series="10:46"
root="sep-AfterNormalization/"
test=root+"conf18 -sc9 - 2CPU and 4 N check improvement"
series="13:10"
'''

root="sep-AfterNormalization/"
test=root+"FINAL conf new-sc9"
series="18:16"

baseAllN_data= pd.read_csv(str(test)+"/allNNAPI.csv" )
bayesNoTris_out=pd.read_csv(str(test)+"/Bayesian OUTPUTNoTris.csv" )#
bayesNoTris_data= pd.read_csv(str(test)+"/bayesNoTris.csv" )#bayesian3 without Triangle change
bayes_data= pd.read_csv(str(test)+"/Bayesian_dataCollection"+str(series)+".csv")  # data of app for bayesian
python_bayes_data= pd.read_csv(str(test)+"/Bayesian OUTPUT"+str(series)+".csv")  
baseDat12= pd.read_csv(str(test)+"/Static_dataCollection"+str(series)+".csv") 

avgQBYS=list(bayes_data['avgQ'].values.reshape(-1,1)[:,0]) #

## data of bayesian fetched
bYReward=list(python_bayes_data['reward'].values.reshape(-1,1)[:-2,0]) # 
ttris=list(python_bayes_data['ttris'].values.reshape(-1,1)[:-2,0]) # 
cu=list(python_bayes_data['cu'].values.reshape(-1,1)[:-2,0]) # cpu usage
gu=list(python_bayes_data['gu'].values.reshape(-1,1)[:-2,0]) # Gpu usage
nu=list(python_bayes_data['nu'].values.reshape(-1,1)[:-2,0]) # NNAPI usage
tris_ratio=list(python_bayes_data['tris'].values.reshape(-1,1)[:-2,0]) # 
ct=list(python_bayes_data['ct'].values.reshape(-1,1)[:-2,0]) # traslated cpu usage
gt=list(python_bayes_data['gt'].values.reshape(-1,1)[:-2,0]) # 
nt=list(python_bayes_data['nt'].values.reshape(-1,1)[:-2,0]) # 
ttris=list(python_bayes_data['ttris'].values.reshape(-1,1)[:-2,0]) # 



best_iteration=bYReward.index(max(bYReward))+1# this is for data2 
best_index_py=best_iteration-1 # index of best of BAYESIAN OUTPUT python result
avgQBY=avgQBYS[best_iteration]

## data of baseline1-2 fetched
ttrisBase12=list(baseDat12['selectedTRatio'].values.reshape(-1,1)[:,0]) # 
percErBase12=list(baseDat12['percentageError'].values.reshape(-1,1)[:,0]) # 
avgQBs=list(baseDat12['avgQ'].values.reshape(-1,1)[:,0]) # 
basedevices12=[]
basedevices12.append(list(baseDat12['Device1'].values.reshape(-1,1)[:,0])[0])
basedevices12.append(list(baseDat12['Device2'].values.reshape(-1,1)[:,0])[0])
basedevices12.append(list(baseDat12['Device3'].values.reshape(-1,1)[:,0])[0])
basedevices12.append(list(baseDat12['Device4'].values.reshape(-1,1)[:,0])[0])
basedevices12.append(list(baseDat12['Device5'].values.reshape(-1,1)[:,0])[0])
basedevices12.append(list(baseDat12['Device6'].values.reshape(-1,1)[:,0])[0])
tRatiobs2=list(baseDat12['selectedTRatio'].values.reshape(-1,1)[:,0])


## data of allNNAPI baseline fetched
basedevicesAllN=[]
basedevicesAllN.append(list(baseAllN_data['Device1'].values.reshape(-1,1)[:,0])[0])
basedevicesAllN.append(list(baseAllN_data['Device2'].values.reshape(-1,1)[:,0])[0])
basedevicesAllN.append(list(baseAllN_data['Device3'].values.reshape(-1,1)[:,0])[0])
basedevicesAllN.append(list(baseAllN_data['Device4'].values.reshape(-1,1)[:,0])[0])
basedevicesAllN.append(list(baseAllN_data['Device5'].values.reshape(-1,1)[:,0])[0])
basedevicesAllN.append(list(baseAllN_data['Device6'].values.reshape(-1,1)[:,0])[0])
tRatioAllN=list(baseAllN_data['selectedTRatio'].values.reshape(-1,1)[:,0])[0]
latencyAllN=[]
latencyAllN.append(list(baseAllN_data['Latency1'].values.reshape(-1,1)[:,0]))
latencyAllN.append(list(baseAllN_data['Latency2'].values.reshape(-1,1)[:,0]))
latencyAllN.append(list(baseAllN_data['Latency3'].values.reshape(-1,1)[:,0]))
latencyAllN.append(list(baseAllN_data['Latency4'].values.reshape(-1,1)[:,0]))
latencyAllN.append(list(baseAllN_data['Latency5'].values.reshape(-1,1)[:,0]))
latencyAllN.append(list(baseAllN_data['Latency6'].values.reshape(-1,1)[:,0]))
avgQAllN=1

## data of baseline3-NoTris fetched
noTrisReward=list(bayesNoTris_out['reward'].values.reshape(-1,1)[:-2,0]) # 

best_iterationN0tris=noTrisReward.index(max(noTrisReward))+1# this is for data2 
iterationN0tris=list(bayesNoTris_data['iteration'])
fBest_IterationNoT=iterationN0tris.index(best_iterationN0tris) #THIS IS FOR BAYESIAN MAIN FILE first index of best iteration
lBest_IterationNoT=len(iterationN0tris) - iterationN0tris[::-1].index(best_iterationN0tris) - 1 # last index of best iteration


basedevicesNoTris=[]
basedevicesNoTris.append(list(bayesNoTris_data['Device1'].values.reshape(-1,1)[:,0])[fBest_IterationNoT])
basedevicesNoTris.append(list(bayesNoTris_data['Device2'].values.reshape(-1,1)[:,0])[fBest_IterationNoT])
basedevicesNoTris.append(list(bayesNoTris_data['Device3'].values.reshape(-1,1)[:,0])[fBest_IterationNoT])
basedevicesNoTris.append(list(bayesNoTris_data['Device4'].values.reshape(-1,1)[:,0])[fBest_IterationNoT])
basedevicesNoTris.append(list(bayesNoTris_data['Device5'].values.reshape(-1,1)[:,0])[fBest_IterationNoT])
basedevicesNoTris.append(list(bayesNoTris_data['Device6'].values.reshape(-1,1)[:,0])[fBest_IterationNoT])

latencyNoTris=[]
latencyNoTris.append(list(bayesNoTris_data['Latency1'].values.reshape(-1,1)[fBest_IterationNoT:lBest_IterationNoT+1,0]))
latencyNoTris.append(list(bayesNoTris_data['Latency2'].values.reshape(-1,1)[fBest_IterationNoT:lBest_IterationNoT+1,0]))
latencyNoTris.append(list(bayesNoTris_data['Latency3'].values.reshape(-1,1)[fBest_IterationNoT:lBest_IterationNoT+1,0]))
latencyNoTris.append(list(bayesNoTris_data['Latency4'].values.reshape(-1,1)[fBest_IterationNoT:lBest_IterationNoT+1,0]))
latencyNoTris.append(list(bayesNoTris_data['Latency5'].values.reshape(-1,1)[fBest_IterationNoT:lBest_IterationNoT+1,0]))
latencyNoTris.append(list(bayesNoTris_data['Latency6'].values.reshape(-1,1)[fBest_IterationNoT:lBest_IterationNoT+1,0]))

tRatioNoTris=1
avgQNoTris=1



'''compare the latency data'''
columns = ['Actual_RT1',  'Actual_RT2', 
           'Actual_RT3',  'Actual_RT4', 
           'Actual_RT5',  'Actual_RT6']

iteration=list(bayes_data['iteration'])
fBest_Iteration_index=iteration.index(best_iteration) #THIS IS FOR BAYESIAN MAIN FILE first index of best iteration

lBest_Iteration_index=len(iteration) - iteration[::-1].index(best_iteration) - 1 # last index of best iteration


latencyBY = {}
latencyBS1 = {}
nrm_latency = {}
latencyBS2={}

latencyBSalN={}
latencyBSNoTr={}

lastbase1Indx=ttrisBase12.index(1)

'''this is for match latency'''

matchLtcyIndx=percErBase12.index(min(percErBase12))
first_index_baseline2=ttrisBase12.index((ttrisBase12[matchLtcyIndx]))
last_index_baseline2 = len(ttrisBase12) - ttrisBase12[::-1].index(ttrisBase12[matchLtcyIndx]) - 1


print("ratio is"+ str(ttrisBase12[first_index_baseline2]))
#end_ratio_index= matchLtcyIndx+7


avgqBaseline2=avgQBs[matchLtcyIndx]
avgqBayes=avgQBYS[fBest_Iteration_index]
avgqBaseline1=avgqBayes

'''3- improvement in latency of HBO vs other baselines - need to calculate Task by Task improvement and then take the average and Sd to show the bargraphs'''


####this is for match latency
tasks = ['AI1',  'AI2', 
           'AI3',  'AI4', 
           'AI5',  'AI6']
j=0
for col in columns:
    actualT_BYS = bayes_data[col][fBest_Iteration_index:lBest_Iteration_index+1].values
    expectedT_BYS = bayes_data[col.replace('Actual', 'Expected')][fBest_Iteration_index:lBest_Iteration_index+1].values
    latencyBY[tasks[j]] = (actualT_BYS - expectedT_BYS).tolist()
    
    #nrm_latency[col]= ( (actualT_BYS - expectedT_BYS)/actualT_BYS  ).tolist()
    actualT_B1 = baseDat12[col][0:lastbase1Indx].values
    expectedT_B1 = baseDat12[col.replace('Actual', 'Expected')][0:lastbase1Indx].values
    latencyBS1[tasks[j]] = (actualT_B1 - expectedT_B1).tolist()

## this is for baseline2 match latency comparison
    actualT_B2 = baseDat12[col][first_index_baseline2:last_index_baseline2+1].values
    expectedT_B2 = baseDat12[col.replace('Actual', 'Expected')][first_index_baseline2:last_index_baseline2+1].values
    latencyBS2[tasks[j]] = (actualT_B2 - expectedT_B2).tolist()

    j+=1



sum_nrm_last=0
improvement1R={}# ratio of improvement vs baseline 1
improvement2R={} # vs baseline2
improvementNotR={} # vs baseline2
improvementAllNR={} # vs baseline2

k=0       
for j in tasks:
    
    listBY =(latencyBY[j])
    listB1 =(latencyBS1[j] )
    listB2=(latencyBS2[j])
    listB3=(latencyNoTris[k])
    listB4=(latencyAllN[k])
    #listNotris=latencyN
    #improvement1R[j] = listB1/listBY
    #improvement2R[j] = listB2/listBY
    improvement1R[j] =[x / y for x, y in zip(listB1, listBY)]
    improvement1R[j]=mean(  improvement1R[j])# this is to get average across all periods of data collection
   
    improvement2R[j] =[x / y for x, y in zip(listB2, listBY)]
    improvement2R[j]=mean(  improvement2R[j])
   
    improvementNotR[j] =[x / y for x, y in zip(listB3, listBY)]
    improvementNotR[j]=mean(  improvementNotR[j])
 
    improvementAllNR[j] =[x / y for x, y in zip(listB4, listBY)]
    improvementAllNR[j]=mean(  improvementAllNR[j])
    k+=1
    #improvement1R[j] =  / 
    #improvement2R[j] = latencyBS2[j] / latencyBY[j]
   # improvement1R[col]=
      #latencyBS1[col]=mean(latencyBS1[col])
      #latencyBY[col]=mean(latencyBY[col])
      #latencyBS2[col]=mean(latencyBS2[col])
      #improvement1R.append((latencyBS1[col]-latencyBY[col])*100 / latencyBY[col])
      #improvement2R.append((latencyBS2[col]-latencyBY[col])*100 / latencyBY[col])
  
     #sum_nrm_last+=nrm_latency[col][len(nrm_latency[col])-1]
     
improvementAllNRList = list(improvementAllNR.values())
improvementNotRList= list(improvementNotR.values())
improvement1RList= list(improvement1R.values())
improvement2RList= list(improvement2R.values())


'''graphs of ratio improvement or the ratio latency of baselines over HBO  '''

bar_labels = [ 'SMQ','SML','BNT','AllN'] ### matchQ, matchL, bayesian No tris, allnnapi

# Calculate means and standard deviations for each list
means = [np.mean(improvement1RList), np.mean(improvement2RList), np.mean(improvementNotRList), np.mean(improvementAllNRList)]
std_devs = [np.std(improvement1RList), np.std(improvement2RList), np.std(improvementNotRList), np.std(improvementAllNRList)]

# X-axis positions for the bars
x = np.arange(len(bar_labels))

# Bar width
width = 0.5

# Create the bar graph
fig, ax = plt.subplots()
rects1 = ax.bar(x, means, width, yerr=std_devs, capsize=5, color="gray")

# Add labels, title, and legend
ax.set_ylabel('Latency Ratio over HBO')

ax.set_xticks(x)
ax.set_xticklabels(bar_labels)
#ax.legend()

# Display the graph
plt.tight_layout()
plt.show()
fig.savefig( str(test)+"/LatencyRatiovsBaselines"+".png" , dpi=300)









''' this is for in detail latency improvement



avg_nrm=sum_nrm_last/len(columns)
print("avg_nrm: "+ str(avg_nrm))
print("Tratio best: "+ str(ttris[best_iteration]))

#result_bs = pd.DataFrame(resultBs)

#compare the latency data for bayesian vs four baselines


# Create a figure and axis
fig, ax = plt.subplots()
# for Tratio stack graph
bar_labels = ['AI1', 'AI2','AI3','AI4', 'AI5','AI6']
bar_values =improvement1R
second_bar_color = 'gray'
plt.title('Latency Improvement (%) vs baseline1')
plt.ylabel('Latency Improvement (%)')
# Create the second bar


for k in range (0,len(bar_values)):
  curV=  bar_values[k]
  #for i, value in enumerate(curV):
  ax.bar(bar_labels[k], bar_values[k], hatch=pattern[k], label=bar_labels[k])
  
ax.legend(loc='best',ncol=3)
#plt.show()
plt.tight_layout()
plt.ylim(0,80)
fig.savefig( str(test)+"/Latency Improvement_baseline1_matchQ"+".png" , dpi=300)


fig, ax = plt.subplots()
# for Tratio stack graph
bar_labels = ['AI1', 'AI2','AI3','AI4', 'AI5','AI6']
bar_values =improvement2R
second_bar_color = 'gray'
#plt.xlabel('')
plt.title('Latency Improvement (%) vs baseline2')
plt.ylabel('Latency Improvement (%)')
# Create the second bar


for k in range (0,len(bar_values)):
  curV=  bar_values[k]
  #for i, value in enumerate(curV):
  ax.bar(bar_labels[k], bar_values[k], hatch=pattern[k], label=bar_labels[k])
  
ax.legend(loc='best',ncol=3)
#plt.show()
plt.tight_layout()
plt.ylim(0,60)
fig.savefig( str(test)+"/Latency Improvement_baseline1_matchAvgLatency"+".png" , dpi=300)


'''




####1- delegate graph

# Initialize dictionaries to count each element


element_counts = {'CPU': 0, 'GPU': 0, 'NNAPI': 0}
delegatebs12=[]   
delegateNoTris=[] 
delegateAllN=[] 
for element in ['CPU', 'GPU', 'NNAPI']:
    count = basedevices12.count(element)
    delegatebs12.append(count)
    
    count = basedevicesAllN.count(element)
    delegateAllN.append(count)
    
    count = basedevicesNoTris.count(element)
    delegateNoTris.append(count)
    

delegateby=[ct[best_iteration],gt[best_iteration],nt[best_iteration]]    

#tratioBs2=   tRatiobs2[len(tRatiobs2)-1] 

# Labels for the bars
bar_labels = ['HBO', 'SMQ','SML','BNT','AllN'] ### matchQ, matchL, bayesian No tris, allnnapi

# Values for the bars
bar_values = [delegateby,delegatebs12,delegatebs12,delegateNoTris,delegateAllN]

# Colors for each component of the first stacked bar
component_colors = [ 'orange','gainsboro', 'gray']
pattern = ['', '.', '|']
fig, ax = plt.subplots()

# Create the first stacked bar with components
cc=0
cg=0
cn=0
delegateLabl=['CPU', 'GPU', 'NNAPI']
for k in range (0,len(bar_values)):
  bottom = 0
  curV=  bar_values[k]
  for i, value in enumerate(curV):
    if(delegateLabl[i]=="CPU" and cc==0):
      ax.bar(bar_labels[k], value, bottom=bottom, label=delegateLabl[i],hatch=pattern[i],color=component_colors[i])
      cc=1
    elif(delegateLabl[i]=="GPU" and cg==0):
        ax.bar(bar_labels[k], value, bottom=bottom, label=delegateLabl[i],hatch=pattern[i],color=component_colors[i])
        cg=1
    elif(delegateLabl[i]=="NNAPI" and cn==0):
      ax.bar(bar_labels[k], value, bottom=bottom, label=delegateLabl[i],hatch=pattern[i],color=component_colors[i])
      cn=1
    else:
        ax.bar(bar_labels[k], value, bottom=bottom,hatch=pattern[i],color=component_colors[i])
       
    bottom += value

# Add labels and title
#plt.xlabel('Delegate per ')
plt.ylabel('# of Tasks')
#plt.title('Stacked and Individual Bar Graph')
# Add legend for the components in the first bar
ax.legend(loc='upper right')
# Show the plot
plt.show()
fig.savefig( str(test)+"/DelegatevsBaselines"+".png" , dpi=300)


###2- Average Q vs Triangle Ratio
tratioBy= ttris[best_iteration]
tratioBs1=  tratioBy 
tratioBs2=  ttrisBase12[first_index_baseline2] 
tRATIO_bar_values = [tratioBy,tratioBs1,tratioBs2,tRatioNoTris,tRatioAllN]


avgQ_bar_values=[avgqBayes,avgqBaseline1,avgqBaseline2 ,avgQNoTris,avgQAllN]

second_bar_color = 'gray'


fig, ax = plt.subplots()
ax2 = ax.twinx()

# Calculate the X-coordinate positions for the bars
x_positions = np.arange(len(bar_labels))
legend_labels = []
bar_width = 0.4  # Adjust the width of the bars as needed
col="#1874CD"
for k in range(len(bar_labels)):
    x_pos = x_positions[k]
    label = bar_labels[k]
    if(k==0):
      ax.bar(x_pos, tRATIO_bar_values[k], width=bar_width,color=col,label='T Ratio')
      ax2.bar(x_pos + bar_width, avgQ_bar_values[k], width=bar_width, color='gainsboro', hatch='.',label='Average Quality')
    else:
       ax.bar(x_pos, tRATIO_bar_values[k], width=bar_width,color=col)
       ax2.bar(x_pos + bar_width, avgQ_bar_values[k], width=bar_width, color='gainsboro', hatch='.')
  
    # Add labels to the list for the legend
    legend_labels.extend([f'T Ratio', f'Average Quality'])

ax.set_ylabel('Triangle Count Ratio (0-1)')
ax2.set_ylabel('Average Quality (0-1)')

# Get the legend handles and labels from both axes
lines, _ = ax.get_legend_handles_labels()
lines2, _ = ax2.get_legend_handles_labels()

# Create a combined legend with labels from both axes
legend = ax.legend(lines + lines2, legend_labels, loc="lower right",handlelength=0.8 ,handletextpad=0.3,bbox_to_anchor=(1.02, 0.0),ncol=2)
legend2 = ax2.legend(lines + lines2, legend_labels, loc="lower right",handlelength=0.8,handletextpad=0.3 ,bbox_to_anchor=(1.02, 0.0),ncol=2)

    
plt.xticks(rotation=45, fontsize=12)

# Create separate artists for the legend items
#legend_artist_T = plt.Line2D([0], [0], color=col, lw=10, label='T Ratio')
#legend_artist_Q = plt.Line2D([0], [0], color='gainsboro', lw=10, label='Average Quality',hatch='.')

# Set the X-axis labels and positions
ax.set_xticks(x_positions + bar_width / 2)
ax.set_xticklabels(bar_labels)

# Rotate x-axis labels and set a smaller fontsize

# Combine the legend artists using ax.legend()
#ax.legend(handles=[legend_artist_T, legend_artist_Q], loc="lower right")
#ax2.legend(handles=[legend_artist_T, legend_artist_Q], loc="lower right")

fig.savefig( str(test)+"/TrisRvsAvgQ_vsBaselines"+".png" , dpi=300)




