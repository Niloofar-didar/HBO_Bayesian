#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Dec 12 09:19:36 2023

@author: niloofar
"""

"""
This is for creating the user study result for HBO vs SML and both vs high quality objects
Created on Sun Sep 10 21:46:42 2023

@author: niloofar
"""
import pandas as pd

from math import isnan
from statistics import mean
from sklearn.preprocessing import PolynomialFeatures
from sklearn.linear_model import LinearRegression
import pandas as pd
import numpy as np
import random
import matplotlib.pyplot as plt
import csv
import statistics
import math 
from sklearn.datasets import load_boston
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error, r2_score
from matplotlib import pyplot as plt
from matplotlib import pyplot as plt2
from matplotlib import pyplot as plt3
import os.path
from os import path
from matplotlib import rcParams
import datetime 
from datetime import datetime
from scipy.stats import linregress
import matplotlib as mpl

#mpl.rcParams['axes.formatter.useoffset'] = False

from matplotlib.pyplot import figure

'''stack graph for the best case'''
import matplotlib.pyplot as plt



col="#1874CD"
col2='#b3b3b3'
colors=[col, "#c1272d",'orange',"#008176"]

plt.rcParams['font.size'] = '20'
plt.rcParams['lines.markersize'] = 22
plt.rcParams["font.family"] = "Times New Roman"
plt.rcParams["axes.labelweight"] = "bold"
plt.rcParams["figure.autolayout"] = True


markers=['o', '.','1','s']


root="ustudy_hbo.csv"

ustudy= pd.read_csv(root)


hboClose=list(ustudy['HBO-close'].values.reshape(-1,1)[:,0]) # 
smlClose=list(ustudy['SML-close'].values.reshape(-1,1)[:,0]) # 
hboFar=list(ustudy['HBO-far'].values.reshape(-1,1)[:,0]) # cpu usage
smlFar=list(ustudy['SML-far'].values.reshape(-1,1)[:,0]) # Gpu usage

hboClose_avg=mean(hboClose)
smlClose_avg= mean(smlClose)
hboFar_avg=mean(hboFar)
smlFar_avg=mean(smlFar)


'''Graph for PAR comparison'''
#fig_width = 6  # Width in inches
#fig_height = 4  # Height in inches
# Create a new figure with the desired figsize
fig, ax = plt.subplots()
#fig, ax = plt.subplots(figsize=(fig_width, fig_height))
#ax2 = ax.twinx()
#labels = ["HBO-close", "SML-close","HBO-far","SML-far"]
labels = ["HBO", "SML","HBO","SML"]
# Create a bar graph
colors = ['orange','#00BFFF','#1f77b4', '#ff7f0e', '#2ca02c', '#d62728', '#9467bd', '#8c564b']
width = 0.21
k=2
maxR=25
x=[0.3,0.6,0.9,1.2]


bar1=ax.bar(x[0], hboFar_avg, width,yerr=np.std(hboFar), label=labels[0], color=colors[3])
bar2=ax.bar(x[1], smlFar_avg, width, yerr=np.std(smlFar),label=labels[1],hatch ='/', color=colors[2])

bar3=ax.bar( x[2], hboClose_avg, width, yerr=np.std(hboClose),color=colors[3])
ax.bar(x[3], smlClose_avg, width,yerr=np.std(smlClose),hatch ='/', color=colors[2])

ax.plot([0.75,0.75],[-1,5.1],color='red',linestyle="-", linewidth=3)
ax.text(0.45, -0.38, 'Far', ha='center', va='center', color='black',fontsize=22)
ax.text(1.05, -0.38, 'Close', ha='center', va='center', color='black',fontsize=22)



ax.plot()
ax.set_yticks([1,2,3,4,5])
ax.set_xticks([])
#ax.set_xticklabels([])
ax.set_ylabel("User Score (1-5)")
spc=0.15
ax.set_ylim(0,5.2)
ax.legend(ncol=2, loc='lower right',columnspacing=spc,handletextpad=0.20,handlelength=0.85,labelspacing=0.14,fontsize=22)
#ax2.legend(handles=legend_handles,ncol=2, loc='best',columnspacing=spc,handletextpad=0.24,handlelength=1.0)
label_fontsize=16
y_ticks=list(ax.get_yticks())
#y_ticks.remove(6)
fig.savefig( "UserStudy.pdf", dpi=300, bbox_inches = 'tight' )



















