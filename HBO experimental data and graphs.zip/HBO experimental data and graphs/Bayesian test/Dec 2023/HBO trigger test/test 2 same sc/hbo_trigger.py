#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Dec 14 00:19:59 2023

@author: niloofar
"""


"""
This is for graphs of HBO trigger
@author: niloofar
"""
import pandas as pd

from math import isnan
from statistics import mean
from sklearn.preprocessing import PolynomialFeatures
from sklearn.linear_model import LinearRegression
import pandas as pd
import numpy as np
import random
import matplotlib.pyplot as plt
import csv
import statistics
import math 
from sklearn.datasets import load_boston
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error, r2_score
from matplotlib import pyplot as plt
from matplotlib import pyplot as plt2
from matplotlib import pyplot as plt3
import os.path
from os import path
from matplotlib import rcParams
import datetime 
from datetime import datetime
from scipy.stats import linregress
import matplotlib as mpl

#mpl.rcParams['axes.formatter.useoffset'] = False

from matplotlib.pyplot import figure

'''stack graph for the best case'''
import matplotlib.pyplot as plt



col="#1874CD"
col2='#b3b3b3'
colors=[col, "#c1272d",'orange',"#008176"]

plt.rcParams['font.size'] = '20'
plt.rcParams['lines.markersize'] = 4
plt.rcParams["font.family"] = "Times New Roman"
plt.rcParams["axes.labelweight"] = "bold"
plt.rcParams["figure.autolayout"] = True


markers=['o', '.','1','s']


root="HBO/"
file="Quality21:37.csv"


#root="baseline periodic/"
#file="Quality23:48.csv"

hbo= pd.read_csv(root+file)

htime=list(hbo['time'].values.reshape(-1,1)[:,0]) # 
bt=list(hbo['reward_bt'].values.reshape(-1,1)[:,0]) # 
hbo_running=list(hbo['hbo_running'].values.reshape(-1,1)[:,0]) # best_bt
best_bt=list(hbo['best_bt'].values.reshape(-1,1)[:,0]) # best_bt 
bt_err=list(hbo['bt_error'].values.reshape(-1,1)[:,0])

rewards=[]
hbo_run=[]
indexes=[]
bt_error=[]

for i in range (1,len(bt)-1):
    #if( i%5==0):
    if(htime[i]!=htime[i-1])    :
        #indexes.append(i)
        hbo_run.append(hbo_running[i])
        rewards.append(bt[i])
        bt_error.append(bt_err[i])

rewards2=[]
hbo_run2=[]
indexes2=[]
bt_error2=[]

for i in range (0,len(hbo_run)-1):
     #if( hbo_run[i]==0 or
     if(   (  hbo_run[i]==0 and hbo_run[i+1]==1)):
        indexes.append(i)
        
     hbo_run2.append(hbo_run[i])
     rewards2.append(rewards[i])
     bt_error2.append(bt_error[i])
 
indexes2.append(2)      
'''  
for i in range (0,len(hbo_run2)):       
        if(hbo_run2[i]==1):
            print(i)
            indexes2.append(i)
'''

time=list(range(1,len(rewards2)+1) )   
fig, ax = plt.subplots() 
plt.plot(time ,rewards2 ,linestyle='none',marker=".",linewidth=1)   

plt.plot(time[1] ,rewards2[1] ,marker='x', markersize=9,label='HBO', color='r',markeredgewidth=2) 

#indexes2.remove(0)
for k in indexes:
  plt.plot(time[k] ,rewards2[k] ,marker='x', markersize=9, color='r',markeredgewidth=2) 


plt.xlabel('Samples')  
plt.ylabel('Reward') 
# Set the x-axis tick positions and labels
#plt.xticks(time)
ax.legend(loc="best", ncol=4,columnspacing=0.2,handletextpad=0.21,labelspacing = 0.14)#, fontsize=14) 
plt.tight_layout()
fig.savefig( root+"HBOrewardvsTime"+".pdf" )


bound=[-0.1]*(len(bt_error2))
bound2=[0.05]*(len(bt_error2))
fig, ax = plt.subplots() 
plt.plot(time ,bt_error2 ,linestyle='none',marker="*",linewidth=1,color='g',markersize=7)   
plt.plot(time ,bound , markersize=9, color='r') 
plt.plot(time ,bound2 , markersize=9, color='r') 

plt.xlabel('Samples')  
plt.ylabel('Percentile Reward Error') 
# Set the x-axis tick positions and labels
#plt.xticks(time)
ax.legend(loc="best", ncol=4,columnspacing=0.2,handletextpad=0.21,labelspacing = 0.14)#, fontsize=14) 
plt.tight_layout()
fig.savefig( root+"bt_error"+".pdf" )

